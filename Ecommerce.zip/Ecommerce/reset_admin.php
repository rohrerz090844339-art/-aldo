<?php
$host = getenv('CTU_DB_HOST') ?: '127.0.0.1';
$name = getenv('CTU_DB_NAME') ?: 'ctu_bsit_rentals';
$user = getenv('CTU_DB_USER') ?: 'root';
$pass = getenv('CTU_DB_PASSWORD');
$pass = ($pass === false) ? '' : $pass;

try {
    $pdo = new PDO("mysql:host=$host;dbname=$name;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    $newHash = password_hash('admin123', PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("UPDATE admin_users SET password_hash = ?");
    $stmt->execute([$newHash]);
    $updated = $stmt->rowCount();

    $rows = $pdo->query("SELECT id, username, email, password_hash FROM admin_users")->fetchAll(PDO::FETCH_ASSOC);
    $allOk = true;
    foreach ($rows as $r) {
        if (!password_verify('admin123', $r['password_hash'])) $allOk = false;
    }

    @unlink(__FILE__);

    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8">
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#0f172a;}
    .box{background:#1e293b;color:#fff;padding:40px;border-radius:16px;text-align:center;max-width:400px;}
    .ok{color:#4ade80;font-size:48px;} .info{color:#94a3b8;margin-top:8px;font-size:14px;}
    a{display:inline-block;margin-top:24px;padding:12px 28px;background:#6366f1;color:#fff;text-decoration:none;border-radius:8px;font-weight:600;}
    </style></head><body><div class="box">';

    if ($allOk) {
        echo '<div class="ok">✓</div>
        <h2>Admin Password Reset!</h2>
        <p>Updated <strong>' . $updated . '</strong> admin account(s).</p>
        <div class="info">Username: <strong>admin</strong><br>Password: <strong>admin123</strong></div>
        <a href="index.html">Go Back to Site</a>';
    } else {
        echo '<div style="color:#f87171;font-size:48px;">✗</div>
        <h2>Verification Failed</h2>
        <p>Hash was updated but verification failed. Contact support.</p>';
    }

    echo '</div></body></html>';

} catch (Exception $e) {
    @unlink(__FILE__);
    header('Content-Type: text/plain');
    echo "DB ERROR: " . $e->getMessage() . "\n";
    echo "Check that XAMPP MySQL is running and the database 'ctu_bsit_rentals' exists.";
}
