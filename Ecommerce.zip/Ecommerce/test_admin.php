<?php
header('Content-Type: text/plain');

$host = getenv('CTU_DB_HOST') ?: '127.0.0.1';
$name = getenv('CTU_DB_NAME') ?: 'ctu_bsit_rentals';
$user = getenv('CTU_DB_USER') ?: 'root';
$pass = getenv('CTU_DB_PASSWORD');
$pass = ($pass === false) ? '' : $pass;

echo "DB: mysql:host=$host;dbname=$name user=$user\n\n";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$name;charset=utf8mb4", $user, $pass);
    echo "Connected OK\n\n";

    $admins = $pdo->query("SELECT id, username, email, password_hash FROM admin_users")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($admins as $a) {
        $ok = password_verify('admin123', $a['password_hash']);
        echo "ID {$a['id']}: username={$a['username']} | email={$a['email']}\n";
        echo "  verify('admin123'): " . ($ok ? "PASS" : "FAIL") . "\n";
        echo "  hash: {$a['password_hash']}\n\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
