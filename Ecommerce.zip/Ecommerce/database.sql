CREATE DATABASE IF NOT EXISTS ctu_bsit_rentals
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ctu_bsit_rentals;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(40) NOT NULL UNIQUE,
  full_name VARCHAR(140) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  phone VARCHAR(30) NOT NULL,
  school VARCHAR(190) NOT NULL,
  program VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('student') NOT NULL DEFAULT 'student',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS admin_users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL UNIQUE,
  full_name VARCHAR(140) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO admin_users (id, username, full_name, email, password_hash)
VALUES
  (1, 'admin', 'CTU BSIT Administrator', 'bsit.admin@ctu-daanbantayan.local', '$2y$10$28e4xAV7zz0mqStD5IOQFOLCMapHD19turtC32UojzL7c4A1cKnH2'),
  (2, 'CTU-DB-BSIT-ADMIN', 'CTU Daanbantayan BSIT Administrator', 'admin@ctu-daanbantayan.local', '$2y$10$28e4xAV7zz0mqStD5IOQFOLCMapHD19turtC32UojzL7c4A1cKnH2')
ON DUPLICATE KEY UPDATE id = VALUES(id);

CREATE TABLE IF NOT EXISTS inventory (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(190) NOT NULL,
  category ENUM('microcontroller', 'prototyping', 'iot', 'cables', 'stationery') NOT NULL,
  category_label VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  specs JSON NOT NULL,
  daily_rate DECIMAL(10,2) UNSIGNED NOT NULL,
  deposit DECIMAL(10,2) UNSIGNED NOT NULL,
  stock_total INT UNSIGNED NOT NULL,
  item_condition ENUM('Excellent', 'Good', 'Fair') NOT NULL DEFAULT 'Good',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

ALTER TABLE inventory ADD COLUMN IF NOT EXISTS is_active TINYINT(1) NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS rentals (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  inventory_id BIGINT UNSIGNED NOT NULL,
  start_date DATE NOT NULL,
  due_date DATE NOT NULL,
  daily_rate DECIMAL(10,2) UNSIGNED NOT NULL,
  deposit DECIMAL(10,2) UNSIGNED NOT NULL,
  payment_method ENUM('Cash', 'GCash', 'Maya') NOT NULL,
  status ENUM('active', 'returned') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  returned_at TIMESTAMP NULL DEFAULT NULL,
  CONSTRAINT rentals_user_fk FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT rentals_inventory_fk FOREIGN KEY (inventory_id) REFERENCES inventory(id),
  INDEX rentals_user_status_idx (user_id, status),
  INDEX rentals_inventory_status_idx (inventory_id, status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS rental_returns (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  rental_id BIGINT UNSIGNED NOT NULL UNIQUE,
  processed_by BIGINT UNSIGNED NOT NULL,
  condition_on_return ENUM('Excellent', 'Good', 'Fair', 'Damaged') NOT NULL DEFAULT 'Good',
  notes TEXT NULL,
  returned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT rental_returns_rental_fk FOREIGN KEY (rental_id) REFERENCES rentals(id),
  CONSTRAINT rental_returns_staff_fk FOREIGN KEY (processed_by) REFERENCES admin_users(id),
  INDEX rental_returns_returned_at_idx (returned_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS overdue_records (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  rental_id BIGINT UNSIGNED NOT NULL UNIQUE,
  detected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  days_overdue INT UNSIGNED NOT NULL DEFAULT 1,
  status ENUM('open', 'resolved') NOT NULL DEFAULT 'open',
  resolved_at TIMESTAMP NULL DEFAULT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT overdue_records_rental_fk FOREIGN KEY (rental_id) REFERENCES rentals(id),
  INDEX overdue_records_status_days_idx (status, days_overdue),
  INDEX overdue_records_detected_idx (detected_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS system_settings (
  id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  overdue_rate DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 20.00,
  max_duration_days SMALLINT UNSIGNED NOT NULL DEFAULT 14,
  deposit_percent DECIMAL(5,2) UNSIGNED NOT NULL DEFAULT 30.00,
  updated_by BIGINT UNSIGNED NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT system_settings_admin_fk FOREIGN KEY (updated_by) REFERENCES admin_users(id)
) ENGINE=InnoDB;

INSERT INTO system_settings (id, overdue_rate, max_duration_days, deposit_percent)
VALUES (1, 20.00, 14, 30.00)
ON DUPLICATE KEY UPDATE id = VALUES(id);

CREATE TABLE IF NOT EXISTS damage_reports (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  rental_id BIGINT UNSIGNED NOT NULL,
  reported_by BIGINT UNSIGNED NOT NULL,
  incident_type ENUM('damaged', 'lost') NOT NULL,
  description TEXT NOT NULL,
  estimated_cost DECIMAL(10,2) UNSIGNED NULL,
  status ENUM('reported', 'under_review', 'resolved') NOT NULL DEFAULT 'reported',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT damage_reports_rental_fk FOREIGN KEY (rental_id) REFERENCES rentals(id),
  CONSTRAINT damage_reports_reporter_fk FOREIGN KEY (reported_by) REFERENCES users(id),
  INDEX damage_reports_rental_idx (rental_id),
  INDEX damage_reports_created_idx (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payment_records (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  rental_id BIGINT UNSIGNED NOT NULL,
  recorded_by BIGINT UNSIGNED NULL,
  payment_type ENUM('rental_fee', 'deposit', 'refund', 'fine') NOT NULL,
  amount DECIMAL(10,2) UNSIGNED NOT NULL,
  method ENUM('Cash', 'GCash', 'Maya', 'Other') NOT NULL,
  reference VARCHAR(120) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT payment_records_rental_fk FOREIGN KEY (rental_id) REFERENCES rentals(id),
  INDEX payment_records_rental_idx (rental_id),
  INDEX payment_records_type_idx (payment_type),
  INDEX payment_records_created_idx (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS suppliers (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(190) NOT NULL,
  contact_name VARCHAR(140) NOT NULL,
  email VARCHAR(190) NULL,
  supplied_items VARCHAR(500) NOT NULL DEFAULT '',
  rating TINYINT UNSIGNED NULL,
  status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  created_by BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT suppliers_admin_fk FOREIGN KEY (created_by) REFERENCES admin_users(id),
  INDEX suppliers_status_idx (status),
  INDEX suppliers_name_idx (name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notifications (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  rental_id BIGINT UNSIGNED NULL,
  subject VARCHAR(190) NOT NULL,
  message TEXT NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at TIMESTAMP NULL DEFAULT NULL,
  CONSTRAINT notifications_user_fk FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT notifications_rental_fk FOREIGN KEY (rental_id) REFERENCES rentals(id),
  CONSTRAINT notifications_admin_fk FOREIGN KEY (created_by) REFERENCES admin_users(id),
  INDEX notifications_user_created_idx (user_id, created_at),
  INDEX notifications_user_read_idx (user_id, read_at)
) ENGINE=InnoDB;

INSERT INTO inventory
  (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
SELECT
  'Arduino Uno R3 Starter Kit', 'microcontroller', 'Microcontroller',
  'Starter kit for introductory programming, electronics, and classroom projects.',
  JSON_ARRAY('Arduino Uno R3 compatible board', 'USB cable', 'LEDs and resistors', 'Basic jumper wires'),
  35, 300, 1, 'Good'
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE name = 'Arduino Uno R3 Starter Kit');

INSERT INTO inventory
  (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
SELECT
  'ESP32-WROOM-32 Development Kit', 'microcontroller', 'Microcontroller',
  'Wi-Fi and Bluetooth development board for connected devices and IoT projects.',
  JSON_ARRAY('ESP32-WROOM-32 development board', 'Wi-Fi and Bluetooth', 'USB programming cable', 'Breadboard-compatible pins'),
  45, 350, 1, 'Good'
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE name = 'ESP32-WROOM-32 Development Kit');

INSERT INTO inventory
  (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
SELECT
  'IoT Sensor Starter Kit', 'iot', 'IoT & Wireless',
  'Multi-sensor kit for Arduino and ESP32 environmental and automation projects.',
  JSON_ARRAY('DHT11 temperature and humidity sensor', 'HC-SR04 ultrasonic sensor', 'PIR motion sensor', 'Soil moisture sensor', 'Photoresistor module'),
  40, 320, 1, 'Good'
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE name = 'IoT Sensor Starter Kit');

INSERT INTO inventory
  (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
SELECT
  'Breadboard & Jumper Wire Prototyping Kit', 'prototyping', 'Prototyping',
  'Reusable solderless prototyping kit for building and testing circuits.',
  JSON_ARRAY('830-point solderless breadboard', 'Assorted male-to-male jumper wires', 'LED assortment', 'Resistor assortment'),
  15, 150, 1, 'Good'
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE name = 'Breadboard & Jumper Wire Prototyping Kit');

INSERT INTO inventory
  (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
SELECT
  'Digital Multimeter', 'prototyping', 'Prototyping',
  'Handheld meter for basic electronics troubleshooting and laboratory exercises.',
  JSON_ARRAY('AC and DC voltage measurement', 'DC current measurement', 'Resistance measurement', 'Continuity and diode test'),
  25, 250, 1, 'Good'
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE name = 'Digital Multimeter');

INSERT INTO inventory
  (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
SELECT
  'Cat6 Ethernet Cable (5m)', 'cables', 'Cables',
  'Five-meter Ethernet cable for networking labs and device connections.',
  JSON_ARRAY('5-meter Cat6 cable', 'RJ45 connectors', 'Suitable for Gigabit Ethernet'),
  10, 80, 1, 'Good'
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE name = 'Cat6 Ethernet Cable (5m)');

INSERT INTO inventory
  (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
SELECT
  'Casio Scientific Calculator (fx-991ES Plus)', 'stationery', 'Academic Stationery & Math',
  'Standard non-programmable scientific calculator approved for university exams, engineering, and mathematics coursework across all CTU programs.',
  JSON_ARRAY('417 functions', 'Natural Textbook Display', 'Solar plus battery dual power', 'Approved for CTU departmental exams'),
  15, 150, 5, 'Excellent'
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE name = 'Casio Scientific Calculator (fx-991ES Plus)');

INSERT INTO inventory
  (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
SELECT
  'Engineering Technical Drafting Kit', 'stationery', 'Drafting & Architecture',
  'Complete drafting set for Engineering, Architecture, and Industrial Technology students doing plates, drawings, and blueprint exercises.',
  JSON_ARRAY('24-inch acrylic T-square', '30/60 and 45/90 drafting triangles', 'Precision compass & divider set', 'Architectural scale ruler'),
  25, 200, 4, 'Good'
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE name = 'Engineering Technical Drafting Kit');

INSERT INTO inventory
  (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
SELECT
  'Wireless Presentation Clicker & Laser Pointer', 'stationery', 'Presentation & Defense',
  'Ergonomic wireless presenter remote with bright laser pointer for capstone defenses, teaching demonstrations, and thesis reports.',
  JSON_ARRAY('Plug-and-play USB receiver', 'Up to 15m operating range', 'Slide navigation & black screen toggle', 'Rechargeable battery'),
  20, 180, 4, 'Excellent'
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE name = 'Wireless Presentation Clicker & Laser Pointer');

INSERT INTO inventory
  (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
SELECT
  'Laboratory Gown & Safety Goggles Set', 'stationery', 'Laboratory Gear',
  'Official white cotton laboratory gown with impact-resistant splash safety goggles required for science, chemistry, and workshop lab sessions.',
  JSON_ARRAY('Heavy-duty white cotton lab coat', 'Anti-fog splash goggles', 'Three reinforced pockets', 'Standard university lab compliance'),
  20, 150, 6, 'Good'
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE name = 'Laboratory Gown & Safety Goggles Set');

ALTER TABLE rentals MODIFY COLUMN status ENUM('pending','approved','active','returned','rejected') NOT NULL DEFAULT 'pending';
