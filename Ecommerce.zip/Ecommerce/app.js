(function () {
  function todayLocal() {
    var date = new Date();
    return date.getFullYear() + "-" +
      String(date.getMonth() + 1).padStart(2, "0") + "-" +
      String(date.getDate()).padStart(2, "0");
  }

  var state = {
    loggedIn: false,
    adminMode: false,
    currentPage: "landing",
    currentAdminView: "admin-dashboard",
    currentReportTab: "rental",
    user: {
      id: "",
      name: "",
      studentId: "",
      email: "",
      college: "Cebu Technological University",
      program: "Bachelor of Science in Information Technology"
    },
    inventory: [],
    myLoans: [],
    history: [],

    settings: {
      overdueRate: 20,
      maxDuration: 14,
      depositPercent: 30
    },
    adminData: {
      stationery: [],
      rentalRequests: [],
      customers: [],
      payments: [],
      overdue: [],
      damage: [],
      users: []
    },
    availabilityCheckId: 0
  };

  function $(id) { return document.getElementById(id); }
  function $$(sel, root) { return (root || document).querySelectorAll(sel); }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (character) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[character];
    });
  }

  function apiRequest(action, options) {
    var requestOptions = options || {};
    var actionParts = action.split("&");
    var url = "api.php?action=" + encodeURIComponent(actionParts.shift());
    for (var i = 0; i < actionParts.length; i++) {
      var parameter = actionParts[i].split("=");
      url += "&" + encodeURIComponent(parameter[0]) + "=" + encodeURIComponent(parameter.slice(1).join("="));
    }
    requestOptions.credentials = "same-origin";
    requestOptions.headers = requestOptions.headers || {};
    if (requestOptions.body && typeof requestOptions.body !== "string") {
      requestOptions.headers["Content-Type"] = "application/json";
      requestOptions.body = JSON.stringify(requestOptions.body);
    }
    return fetch(url, requestOptions).then(function (response) {
      return response.json().catch(function () {
        throw new Error("The server returned an invalid response.");
      }).then(function (data) {
        if (!response.ok) throw new Error(data.error || "The request could not be completed.");
        return data;
      });
    });
  }

  function applyUser(user) {
    state.user.id = user.id || "";
    state.user.name = user.name || "";
    state.user.studentId = user.student_id || "";
    state.user.email = user.email || "";
    state.user.college = user.school || "Cebu Technological University";
    state.user.program = user.program || "Bachelor of Science in Information Technology";
  }

  function loadInventory() {
    return apiRequest("inventory").then(function (data) {
      state.inventory = data.items || [];
      var availableCount = 0;
      for (var i = 0; i < state.inventory.length; i++) {
        availableCount += state.inventory[i].total - state.inventory[i].rented;
      }
      if ($("homeAvailableUnits")) $("homeAvailableUnits").textContent = availableCount;
      if ($("catalogAvailability")) $("catalogAvailability").textContent = availableCount + " Units Available";
      renderHomeFeatured("all");
      if (state.currentPage === "catalog") renderCatalog("catalogGrid", "all", "");
      if (state.currentPage === "browse") renderCatalog("browseGrid", "all", "");
      if (state.currentPage === "dashboard") renderCatalog("dashRentalGrid", "all", "");
      if (state.adminMode) populateAdminTables();
      if ($("adminAvailableItems")) $("adminAvailableItems").textContent = availableCount;
    });
  }

  function loadSettings() {
    return apiRequest("settings").then(function (data) {
      state.settings = data.settings;
      var durationInput = $("rentDays");
      if (durationInput) durationInput.max = String(state.settings.maxDuration);
      if ($("settingsForm")) {
        $("sOverdue").value = state.settings.overdueRate;
        $("sMaxDays").value = state.settings.maxDuration;
        $("sDepPct").value = state.settings.depositPercent;
      }
      if (state.currentPage === "catalog") renderCatalog("catalogGrid", "all", "");
      if (state.currentPage === "browse") renderCatalog("browseGrid", "all", "");
      if (state.currentPage === "dashboard") renderCatalog("dashRentalGrid", "all", "");
      renderHomeFeatured("all");
    });
  }

  function loadAdminUsers() {
    if (!state.adminMode) return Promise.resolve();
    return Promise.all([apiRequest("users"), apiRequest("admin-users")]).then(function (results) {
      state.adminData.customers = results[0].users || [];
      state.adminData.users = results[1].users || [];
      populateAdminTables();
    });
  }

  function renderReport(tabName) {
    var reportContent = $("reportContent");
    if (!reportContent) return;
    state.currentReportTab = tabName;
    var rows = "";
    var heading = "";
    var summary = "";
    var headers = [];

    if (tabName === "rental") {
      heading = "Rental Volume Report";
      summary = state.myLoans.length + " rental records · " +
        state.myLoans.filter(function (rental) { return rental.status === "active"; }).length + " currently active";
      headers = ["Loan ID", "Student", "Item", "Start date", "Due date", "Status"];
      for (var i = 0; i < state.myLoans.length; i++) {
        var rental = state.myLoans[i];
        rows += "<tr><td>LN-" + escapeHtml(rental.id) + "</td><td>" +
          escapeHtml(rental.student || state.user.name) + "</td><td>" +
          escapeHtml(rental.itemName) + "</td><td>" + escapeHtml(rental.startDate) +
          "</td><td>" + escapeHtml(rental.dueDate) + "</td><td>" +
          escapeHtml(rental.status) + "</td></tr>";
      }
    } else if (tabName === "financial") {
      heading = "Estimated Rental Fees";
      var expectedTotal = 0;
      headers = ["Loan ID", "Student", "Item", "Days", "Rate/day", "Estimated fee"];
      for (var j = 0; j < state.myLoans.length; j++) {
        var feeRental = state.myLoans[j];
        var days = Math.max(1, Math.ceil((new Date(feeRental.dueDate) - new Date(feeRental.startDate)) / 86400000));
        var fee = days * Number(feeRental.dailyRate);
        expectedTotal += fee;
        rows += "<tr><td>LN-" + escapeHtml(feeRental.id) + "</td><td>" +
          escapeHtml(feeRental.student || state.user.name) + "</td><td>" +
          escapeHtml(feeRental.itemName) + "</td><td>" + days + "</td><td>₱" +
          Number(feeRental.dailyRate).toFixed(2) + "</td><td>₱" + fee.toFixed(2) + "</td></tr>";
      }
      summary = "₱" + expectedTotal.toFixed(2) +
        " estimated from rental rates and durations. This is not a record of payments received.";
    } else if (tabName === "inventory") {
      heading = "Inventory Report";
      headers = ["Item", "Category", "Total units", "Available", "Rented"];
      var totalUnits = 0;
      var availableUnits = 0;
      for (var k = 0; k < state.inventory.length; k++) {
        var item = state.inventory[k];
        var available = Number(item.total) - Number(item.rented);
        totalUnits += Number(item.total);
        availableUnits += available;
        rows += "<tr><td>" + escapeHtml(item.name) + "</td><td>" +
          escapeHtml(item.catLabel) + "</td><td>" + Number(item.total) +
          "</td><td>" + available + "</td><td>" + Number(item.rented) + "</td></tr>";
      }
      summary = totalUnits + " active inventory units · " + availableUnits + " available";
    } else if (tabName === "overdue") {
      heading = "Overdue Rentals";
      var today = todayLocal();
      var overdueRentals = state.myLoans.filter(function (rental) {
        return rental.status === "active" && rental.dueDate < today;
      });
      headers = ["Loan ID", "Student", "Item", "Due date", "Days late", "Estimated penalty"];
      for (var n = 0; n < overdueRentals.length; n++) {
        var overdueRental = overdueRentals[n];
        var daysLate = Math.floor((new Date(today) - new Date(overdueRental.dueDate)) / 86400000);
        rows += "<tr><td>LN-" + escapeHtml(overdueRental.id) + "</td><td>" +
          escapeHtml(overdueRental.student || state.user.name) + "</td><td>" +
          escapeHtml(overdueRental.itemName) + "</td><td>" + escapeHtml(overdueRental.dueDate) +
          "</td><td>" + daysLate + "</td><td>₱" +
          (daysLate * Number(state.settings.overdueRate)).toFixed(2) + "</td></tr>";
      }
      summary = overdueRentals.length + " active rentals past their due date. Estimated penalties are not automatically charged.";
    } else {
      return;
    }

    var tableRows = rows || '<tr><td colspan="' + headers.length + '" class="empty-state">No records for this report.</td></tr>';
    reportContent.innerHTML =
      '<div class="report-result"><h3>' + heading + '</h3><p class="report-summary">' +
      escapeHtml(summary) + '</p><div class="table-card"><table class="data-table"><thead><tr>' +
      headers.map(function (header) { return "<th>" + header + "</th>"; }).join("") +
      '</tr></thead><tbody>' + tableRows + '</tbody></table></div></div>';
  }

  function loadDamageReports() {
    if (!state.adminMode) return Promise.resolve();
    return apiRequest("damage-reports").then(function (data) {
      var reports = (data.reports || []).map(function (report) {
        var cost = report.estimatedCost === null
          ? "Not estimated"
          : "₱" + Number(report.estimatedCost).toFixed(2);
        return {
          incId: "DMG-" + report.id,
          student: report.student + " (" + report.studentId + ")",
          item: report.item,
          desc: report.type === "lost" ? "Lost: " + report.description : "Damaged: " + report.description,
          cost: cost,
          status: report.status.replace(/_/g, " "),
          date: report.date
        };
      });
      state.adminData.damage = reports;
      populateAdminTables();
    });
  }

  function loadAdminOperations() {
    if (!state.adminMode) return Promise.resolve();
    return Promise.all([
      apiRequest("payments"),
      apiRequest("overdue")
    ]).then(function (results) {
      state.adminData.payments = results[0].payments || [];
      state.adminData.overdue = results[1].overdue || [];
      populateAdminTables();
    });
  }

  function loadRentals() {
    if (!state.loggedIn) {
      state.myLoans = [];
      state.history = [];
      return Promise.resolve();
    }
    return apiRequest("rentals").then(function (data) {
      state.myLoans = data.rentals || [];
      state.history = state.myLoans.filter(function (rental) { return rental.status === "returned"; });
      if (state.currentPage === "dashboard") renderDashboard();
      if (state.currentPage === "my-rentals") renderMyRentals();
      if (state.currentPage === "history") renderHistory();
      if (state.adminMode) {
        updateAdminMetrics();
        populateAdminTables();
        updateReturnOptions();
      }
    });
  }

  function showRequestError(error) {
    showToast(error.message || "The request could not be completed.", "error");
  }

  function showToast(msg, type) {
    var box = $("toastBox");
    var t = document.createElement("div");
    t.className = "toast " + (type || "info");
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 4200);
  }

  function showModal(id) { $(id).classList.remove("hidden"); }
  function hideModal(id) { $(id).classList.add("hidden"); }

  function navigatePage(page) {
    state.currentPage = page;
    var sections = $$(".page-section");
    for (var i = 0; i < sections.length; i++) { sections[i].classList.remove("active"); }

    var target = null;
    if (!state.loggedIn) {
      if (page === "landing" || page === "catalog" || page === "about") {
        target = $("page-" + page);
      } else {
        showModal("loginModal");
        return;
      }
    } else {
      if (page === "landing") target = $("page-landing");
      else if (page === "catalog") target = $("page-catalog");
      else if (page === "about") target = $("page-about");
      else if (page === "dashboard") target = $("page-user-dashboard");
      else if (page === "browse") target = $("page-user-browse");
      else if (page === "my-rentals") target = $("page-user-my-rentals");
      else if (page === "history") target = $("page-user-history");
    }

    if (target) target.classList.add("active");

    var pubLinks = $$("[data-page]");
    for (var j = 0; j < pubLinks.length; j++) {
      pubLinks[j].classList.toggle("active", pubLinks[j].getAttribute("data-page") === page);
    }
    var uLinks = $$("[data-upage]");
    for (var k = 0; k < uLinks.length; k++) {
      uLinks[k].classList.toggle("active", uLinks[k].getAttribute("data-upage") === page);
    }

    window.scrollTo({ top: 0, behavior: "smooth" });

    if (page === "catalog") renderCatalog("catalogGrid", "all", "");
    if (page === "browse") renderCatalog("browseGrid", "all", "");
    if (page === "dashboard") { renderDashboard(); renderCatalog("dashRentalGrid", "all", ""); }
    if (page === "my-rentals") renderMyRentals();
    if (page === "history") renderHistory();
  }

  function loginUser(user) {
    applyUser(user);
    state.loggedIn = true;
    $("pubNavbar").classList.add("hidden");
    $("userTopbar").classList.remove("hidden");
    $("siteFooter").classList.add("hidden");
    $("userNameSm").textContent = state.user.name;
    $("userAvatarSm").textContent = state.user.name.split(" ").map(function (w) { return w[0]; }).join("");
    navigatePage("dashboard");
    showToast("Welcome, " + state.user.name + "!", "success");
    fetchNotificationCount();
  }

  function logoutUser() {
    apiRequest("logout", { method: "POST" }).then(function () {
      state.loggedIn = false;
      state.adminMode = false;
      state.myLoans = [];
      state.history = [];
      $("pubNavbar").classList.remove("hidden");
      $("userTopbar").classList.add("hidden");
      $("adminShell").classList.add("hidden");
      $("mainContent").style.display = "";
      $("siteFooter").classList.remove("hidden");
      navigatePage("landing");
      renderHomeFeatured("all");
      showToast("You have been logged out.", "info");
    }).catch(showRequestError);
  }

  function enterAdmin() {
    state.adminMode = true;
    $("pubNavbar").classList.add("hidden");
    $("userTopbar").classList.add("hidden");
    $("mainContent").style.display = "none";
    $("siteFooter").classList.add("hidden");
    $("adminShell").classList.remove("hidden");
    navigateAdmin("admin-dashboard");
    Promise.all([loadInventory(), loadRentals(), loadAdminUsers(), loadDamageReports(), loadAdminOperations(), loadSettings()]).then(function () {
      updateAdminMetrics();
      populateAdminTables();
      updateReturnOptions();
      showToast("Administrator dashboard opened.", "success");
    }).catch(showRequestError);
  }

  function exitAdmin() {
    state.adminMode = false;
    state.loggedIn = false;
    state.user = null;
    $("adminShell").classList.add("hidden");
    $("mainContent").style.display = "";
    apiRequest("admin-logout", { method: "POST" }).catch(function () {});
    $("pubNavbar").classList.remove("hidden");
    $("userTopbar").classList.add("hidden");
    $("siteFooter").classList.remove("hidden");
    navigatePage("landing");
    renderHomeFeatured("all");
    showToast("Exited administrator session.", "info");
  }

  function navigateAdmin(view) {
    state.currentAdminView = view;
    var views = $$(".admin-view");
    for (var i = 0; i < views.length; i++) { views[i].classList.remove("active"); }
    var target = $("av-" + view);
    if (target) target.classList.add("active");

    var items = $$(".as-item");
    for (var j = 0; j < items.length; j++) {
      items[j].classList.toggle("active", items[j].getAttribute("data-av") === view);
    }
  }

  function buildItemCard(item) {
    var avail = item.total - item.rented;
    var pct = Math.round((avail / item.total) * 100);
    var fillClass = pct > 50 ? "high" : pct > 20 ? "med" : "low";
    var tagClass = avail > 5 ? "tag-success" : avail > 2 ? "tag-warning" : "tag-danger";

    var specsHtml = "";
    for (var i = 0; i < item.specs.length; i++) {
      specsHtml += "<li>" + escapeHtml(item.specs[i]) + "</li>";
    }

    return '<div class="item-card" data-item-id="' + item.id + '">' +
      '<div class="ic-top">' +
        '<span class="tag ' + tagClass + '">' + avail + ' available</span>' +
      '</div>' +
      '<div class="ic-name">' + escapeHtml(item.name) + '</div>' +
      '<div class="ic-desc">' + escapeHtml(item.desc) + '</div>' +
      '<ul class="ic-specs">' + specsHtml + '</ul>' +
      '<div class="ic-stock-bar"><div class="ic-stock-fill ' + fillClass + '" style="width:' + pct + '%"></div></div>' +
      '<div class="ic-stock-text">' + avail + ' of ' + item.total + ' units available (' + pct + '%)</div>' +
      '<div class="ic-price-row">' +
        '<div class="ic-rate">₱' + Number(item.dailyRate).toFixed(2) + '<small>/day</small></div>' +
        '<div class="ic-deposit">' + String(state.settings.depositPercent).replace(/\.00$/, "") + '% of fee deposit</div>' +
      '</div>' +
      '<button type="button" class="btn-rent" data-rent-id="' + item.id + '">Rent This Item ➔</button>' +
    '</div>';
  }

  function renderCatalog(gridId, category, search) {
    var grid = $(gridId);
    if (!grid) return;
    var html = "";
    for (var i = 0; i < state.inventory.length; i++) {
      var item = state.inventory[i];
      if (category !== "all" && item.category !== category) continue;
      if (search && item.name.toLowerCase().indexOf(search.toLowerCase()) === -1 &&
          item.desc.toLowerCase().indexOf(search.toLowerCase()) === -1 &&
          item.catLabel.toLowerCase().indexOf(search.toLowerCase()) === -1) continue;
      html += buildItemCard(item);
    }
    var emptyMessage = state.inventory.length
      ? "No items match your filter."
      : "No items have been added to the rental inventory yet.";
    grid.innerHTML = html || '<p style="color:var(--text-muted);padding:40px;text-align:center;">' + emptyMessage + '</p>';
  }

  function renderHomeFeatured(category) {
    renderCatalog("homeFeaturedGrid", category, "");
  }

  function renderDashboard() {
    $("dashUserName").textContent = state.user.name.split(" ")[0];
    var activeLoans = state.myLoans.filter(function (loan) { return loan.status === "active"; });
    $("dashActiveCount").textContent = activeLoans.length;
    var dueCount = 0;
    var totalDeposit = 0;
    for (var i = 0; i < activeLoans.length; i++) {
      totalDeposit += Number(activeLoans[i].deposit);
      if (activeLoans[i].dueDate === todayLocal()) dueCount++;
    }
    $("dashDueCount").textContent = dueCount;
    $("dashDepositHeld").textContent = "₱" + totalDeposit;
  }

  function renderMyRentals() {
    var body = $("myRentalsBody");
    if (!body) return;
    var html = "";
    for (var i = 0; i < state.myLoans.length; i++) {
      var ln = state.myLoans[i];
      if (ln.status === "returned") continue;
      var statusClass = ln.status === "active" || ln.status === "approved"
        ? "tag-success"
        : ln.status === "pending" ? "tag-warning" : "tag-neutral";
      var statusTag = '<span class="tag ' + statusClass + '">' + escapeHtml(ln.status) + '</span>';
      html += "<tr>" +
        "<td>" + escapeHtml(ln.itemName) + "</td>" +
        "<td><strong>LN-" + ln.id + "</strong></td>" +
        "<td>" + escapeHtml(ln.startDate) + "</td>" +
        "<td>" + escapeHtml(ln.dueDate) + "</td>" +
        "<td>₱" + ln.dailyRate + "/day</td>" +
        "<td>₱" + ln.deposit + "</td>" +
        "<td>" + statusTag + "</td>" +
        "<td>" + (ln.status === "active"
          ? "<button type='button' class='btn btn-outline btn-xs' data-report-rental='" + escapeHtml(ln.id) + "'>Report issue</button>"
          : "—") + "</td>" +
      "</tr>";
    }
    body.innerHTML = html || '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:40px;">No current rental requests.</td></tr>';
  }

  function renderHistory() {
    var body = $("historyBody");
    if (!body) return;
    var html = "";
    for (var i = 0; i < state.history.length; i++) {
      var h = state.history[i];
      html += "<tr>" +
        "<td>" + escapeHtml(h.itemName) + "</td>" +
        "<td>LN-" + h.id + "</td>" +
        "<td>" + escapeHtml(h.startDate) + " – " + escapeHtml(h.dueDate) + "</td>" +
        "<td>₱" + (h.dailyRate * Math.max(1, Math.ceil((new Date(h.dueDate) - new Date(h.startDate)) / 86400000))) + "</td>" +
        "<td>₱" + h.deposit + "</td>" +
        "<td><span class='tag tag-success'>Returned</span><br>" +
          escapeHtml(h.returnDate ? String(h.returnDate).slice(0, 10) : "Date unavailable") +
          (h.returnCondition ? " · " + escapeHtml(h.returnCondition) : "") +
          (h.returnNotes ? "<br>" + escapeHtml(h.returnNotes) : "") + "</td>" +
      "</tr>";
    }
    body.innerHTML = html || '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:40px;">No history yet.</td></tr>';
  }

  function openRentModal(itemId) {
    var item = null;
    for (var i = 0; i < state.inventory.length; i++) {
      if (state.inventory[i].id === itemId) { item = state.inventory[i]; break; }
    }
    if (!item) return;

    $("rentItemId").value = item.id;
    $("rentModalTitle").textContent = "Rent: " + item.name;
    $("rentItemSummary").innerHTML = '<strong>' + escapeHtml(item.name) + '</strong><br/>' +
      '<span style="font-size:0.82rem;color:var(--text-muted);">' + escapeHtml(item.desc) + '</span>';

    if (state.loggedIn) {
      $("rentName").value = state.user.name;
      $("rentSid").value = state.user.studentId;
    }
    $("rentDays").value = "1";
    $("rentDays").max = String(state.settings.maxDuration);
    $("rentStartDate").min = todayLocal();
    $("rentStartDate").value = todayLocal();

    updateRentCost(item);
    updateRentAvailability();
    showModal("rentModal");
  }

  function updateRentCost(item) {
    var days = parseInt($("rentDays").value) || 1;
    var fee = days * item.dailyRate;
    var deposit = Math.round(fee * state.settings.depositPercent) / 100;
    var total = fee + deposit;
    $("rentCost").innerHTML =
      '<div class="cost-row"><span>Daily Rate</span><span>₱' + item.dailyRate + ' × ' + days + ' days</span></div>' +
      '<div class="cost-row"><span>Rental Period</span><span>' + escapeHtml($("rentStartDate").value || "Choose a start date") + ' · ' + days + ' days</span></div>' +
      '<div class="cost-row"><span>Estimated Rental Fee</span><span>₱' + fee.toFixed(2) + '</span></div>' +
      '<div class="cost-row"><span>Security Deposit (' + state.settings.depositPercent + '% of fee, refundable)</span><span>₱' + deposit.toFixed(2) + '</span></div>' +
      '<div class="cost-row total"><span>Estimated Total</span><span>₱' + total.toFixed(2) + '</span></div>' +
      '<p class="pickup-note">This is an estimate. Your request will be sent to an administrator for review; payment is recorded only after it is actually received.</p>';
  }

  function updateRentAvailability() {
    var status = $("rentAvailability");
    if (!status) return;
    var submitButton = document.querySelector("#rentForm button[type='submit']");
    var itemId = $("rentItemId").value;
    var startDate = $("rentStartDate").value;
    var days = parseInt($("rentDays").value, 10);
    var checkId = ++state.availabilityCheckId;
    if (!itemId || !startDate || !days || days < 1 || days > state.settings.maxDuration) {
      status.textContent = "Choose a valid rental start date and duration to check availability.";
      if (submitButton) submitButton.disabled = true;
      return;
    }
    status.textContent = "Checking item availability for these dates...";
    if (submitButton) submitButton.disabled = true;
    apiRequest("availability&itemId=" + encodeURIComponent(itemId) +
      "&startDate=" + encodeURIComponent(startDate) + "&days=" + encodeURIComponent(days))
      .then(function (data) {
        if (checkId !== state.availabilityCheckId) return;
        status.textContent = data.isAvailable
          ? data.available + " unit(s) are available for the selected dates. The administrator will confirm availability."
          : "This item is unavailable for the selected dates. Choose another date or item.";
        if (submitButton) submitButton.disabled = !data.isAvailable;
      }).catch(function (error) {
        if (checkId !== state.availabilityCheckId) return;
        status.textContent = error.message || "Availability could not be checked.";
        if (submitButton) submitButton.disabled = true;
      });
  }

  function populateAdminTables() {
    var iBody = $("admInventoryBody");
    if (iBody) {
      var iHtml = "";
      for (var j = 0; j < state.inventory.length; j++) {
        var inv = state.inventory[j];
        var a = inv.total - inv.rented;
        iHtml += "<tr>" +
          "<td>AST-" + String(j + 1).padStart(3, "0") + "</td>" +
          "<td>" + escapeHtml(inv.name) + "</td>" +
          "<td><span class='tag tag-primary'>" + escapeHtml(inv.catLabel) + "</span></td>" +
          "<td>₱" + Number(inv.dailyRate).toFixed(2) + "</td>" +
          "<td>₱" + Number(inv.deposit).toFixed(2) + "</td>" +
          "<td>" + Number(inv.total) + "</td>" +
          "<td>" + a + "</td>" +
          "<td><span class='tag tag-neutral'>" + escapeHtml(inv.condition) + "</span></td>" +
          "<td><button type='button' class='btn btn-outline btn-xs' data-edit-inventory='" + escapeHtml(inv.id) + "'>Edit</button> <button type='button' class='btn btn-danger btn-xs' data-delete-inventory='" + escapeHtml(inv.id) + "'>Remove</button></td>" +
        "</tr>";
      }
      iBody.innerHTML = iHtml || '<tr><td colspan="9" class="empty-state">No rental items yet. Add an item to make it available in the catalog.</td></tr>';
    }

    var rBody = $("admRentalsBody");
    if (rBody) {
      var rHtml = "";
      for (var k = 0; k < state.myLoans.length; k++) {
        var rq = state.myLoans[k];
        var days = Math.max(1, Math.ceil((new Date(rq.dueDate) - new Date(rq.startDate)) / 86400000));
        var fee = days * Number(rq.dailyRate);
        var stClass = rq.status === "active" || rq.status === "approved"
          ? "tag-success" : rq.status === "pending" ? "tag-warning" : "tag-neutral";
        var actionButtons = "—";
        if (rq.status === "pending") {
          actionButtons = "<button type='button' class='btn btn-primary btn-xs' data-review-request='" +
            escapeHtml(rq.id) + "' data-decision='approve'>Approve</button> " +
            "<button type='button' class='btn btn-danger btn-xs' data-review-request='" +
            escapeHtml(rq.id) + "' data-decision='reject'>Reject</button>";
        } else if (rq.status === "approved") {
          actionButtons = "<button type='button' class='btn btn-outline btn-xs' data-jump='admin-payments'>Record payment</button> " +
            "<button type='button' class='btn btn-primary btn-xs' data-pickup-rental='" +
            escapeHtml(rq.id) + "'>Verify &amp; mark picked up</button>";
        } else if (rq.status === "active") {
          actionButtons = "<button type='button' class='btn btn-outline btn-xs' data-return-rental='" +
            escapeHtml(rq.id) + "'>Mark returned</button>";
        }
        rHtml += "<tr>" +
          "<td>LN-" + rq.id + "</td>" +
          "<td>" + escapeHtml(rq.student || state.user.name) + "<br><small>" +
            escapeHtml(rq.studentId || "") + "</small></td>" +
          "<td>" + escapeHtml(rq.itemName) + "</td>" +
          "<td>" + escapeHtml(rq.startDate) + " – " + escapeHtml(rq.dueDate) + " (" + days + " days)</td>" +
          "<td>₱" + fee.toFixed(2) + "</td>" +
          "<td>₱" + Number(rq.deposit).toFixed(2) + "</td>" +
          "<td>" + Math.max(0, Number(rq.availableAtDates)) + " unit(s)</td>" +
          "<td><span class='tag " + stClass + "'>" + escapeHtml(rq.status) + "</span></td>" +
          "<td>" + actionButtons + "</td>" +
        "</tr>";
      }
      rBody.innerHTML = rHtml || '<tr><td colspan="9" class="empty-state">No rental records.</td></tr>';
    }

    var cBody = $("admCustomersBody");
    if (cBody) {
      var cHtml = "";
      for (var m = 0; m < state.adminData.customers.length; m++) {
        var c = state.adminData.customers[m];
        var standClass = c.standing === "Good" ? "tag-success" : "tag-danger";
        cHtml += "<tr>" +
          "<td>" + escapeHtml(c.studentId) + "</td>" +
          "<td>" + escapeHtml(c.name) + "</td>" +
          "<td>" + escapeHtml(c.school) + "<br>" + escapeHtml(c.program) + "</td>" +
          "<td>" + escapeHtml(c.email) + "</td>" +
          "<td>" + c.activeRentals + "</td>" +
          "<td>—</td>" +
          "<td><span class='tag tag-neutral'>Registered</span></td>" +
        "</tr>";
      }
      cBody.innerHTML = cHtml || '<tr><td colspan="7" class="empty-state">No registered students.</td></tr>';
    }

    var pBody = $("admPaymentsBody");
    if (pBody) {
      var pHtml = "";
      var paymentTotals = { rental_fee: 0, deposit: 0, refund: 0, fine: 0 };
      for (var n = 0; n < state.adminData.payments.length; n++) {
        var p = state.adminData.payments[n];
        var amount = Number(p.amount);
        if (Object.prototype.hasOwnProperty.call(paymentTotals, p.type)) paymentTotals[p.type] += amount;
        var typeLabels = { rental_fee: "Rental fee", deposit: "Deposit", refund: "Refund", fine: "Fine" };
        pHtml += "<tr>" +
          "<td>PAY-" + escapeHtml(p.id) + "</td>" +
          "<td>" + escapeHtml(p.student) + "</td>" +
          "<td>" + escapeHtml(p.item) + "</td>" +
          "<td>" + escapeHtml(typeLabels[p.type] || p.type) + "</td>" +
          "<td>₱" + amount.toFixed(2) + "</td>" +
          "<td>" + escapeHtml(p.method) + "</td>" +
          "<td>" + escapeHtml(p.reference || "—") + "</td>" +
          "<td>" + escapeHtml(p.date) + "</td>" +
        "</tr>";
      }
      pBody.innerHTML = pHtml || '<tr><td colspan="8" class="empty-state">No payment records have been recorded.</td></tr>';
      $("paymentFeesTotal").textContent = "₱" + paymentTotals.rental_fee.toFixed(2);
      $("paymentDepositsTotal").textContent = "₱" + paymentTotals.deposit.toFixed(2);
      $("paymentRefundsTotal").textContent = "₱" + paymentTotals.refund.toFixed(2);
      $("paymentFinesTotal").textContent = "₱" + paymentTotals.fine.toFixed(2);
    }

    var oBody = $("admOverdueBody");
    if (oBody) {
      var oHtml = "";
      var actualOverdue = state.adminData.overdue;
      for (var o = 0; o < actualOverdue.length; o++) {
        var ov = actualOverdue[o];
        oHtml += "<tr>" +
          "<td>LN-" + escapeHtml(ov.rentalId) + "</td>" +
          "<td>" + escapeHtml(ov.student || state.user.name) + "</td>" +
          "<td>" + escapeHtml(ov.item) + "</td>" +
          "<td>" + escapeHtml(ov.dueDate) + "</td>" +
          "<td><span class='text-danger'>" + escapeHtml(ov.daysOverdue) + " days</span></td>" +
          "<td>₱" + (Number(ov.daysOverdue) * Number(state.settings.overdueRate)).toFixed(2) + " est.</td>" +
          "<td>₱" + Number(ov.deposit).toFixed(2) + "</td>" +
          "<td>—</td>" +
        "</tr>";
      }
      oBody.innerHTML = oHtml || '<tr><td colspan="8" class="empty-state">No active overdue rentals.</td></tr>';
    }

    var dBody = $("admDamageBody");
    if (dBody) {
      var dHtml = "";
      for (var q = 0; q < state.adminData.damage.length; q++) {
        var d = state.adminData.damage[q];
        dHtml += "<tr>" +
          "<td>" + escapeHtml(d.incId) + "</td>" +
          "<td>" + escapeHtml(d.student) + "</td>" +
          "<td>" + escapeHtml(d.item) + "</td>" +
          "<td>" + escapeHtml(d.desc) + "</td>" +
          "<td><span class='text-danger'>" + escapeHtml(d.cost) + "</span></td>" +
          "<td><span class='tag tag-warning'>" + escapeHtml(d.status) + "</span></td>" +
          "<td>" + escapeHtml(d.date) + "</td>" +
        "</tr>";
      }
      dBody.innerHTML = dHtml || '<tr><td colspan="7" class="empty-state">No damage or loss reports have been submitted.</td></tr>';
    }

    var uBody = $("admUsersBody");
    if (uBody) {
      var uHtml = "";
      for (var t = 0; t < state.adminData.users.length; t++) {
        var u = state.adminData.users[t];
        var isCurrentUser = String(u.id) === String(state.user.id);
        var nextRole = u.role === "admin" ? "student" : "admin";
        uHtml += "<tr>" +
          "<td>" + escapeHtml(u.name) + "</td>" +
          "<td>" + escapeHtml(u.studentId) + "</td>" +
          "<td>" + escapeHtml(u.email) + "</td>" +
          "<td>" + (u.role === "admin" ? "Administrator" : "Student") + "</td>" +
          "<td><span class='tag tag-success'>Active</span></td>" +
          "<td>" + (isCurrentUser
            ? "Current account"
            : "<button type='button' class='btn btn-outline btn-xs' data-change-role='" + escapeHtml(u.id) +
              "' data-next-role='" + nextRole + "'>" + (nextRole === "admin" ? "Make admin" : "Revoke admin") + "</button>") + "</td>" +
        "</tr>";
      }
      uBody.innerHTML = uHtml || '<tr><td colspan="6" class="empty-state">No registered accounts are available.</td></tr>';
    }

    renderReport(state.currentReportTab);
  }

  function updateAdminMetrics() {
    if (!$("adminTotalRentals")) return;
    var active = state.myLoans.filter(function (rental) { return rental.status === "active"; });
    var pending = state.myLoans.filter(function (rental) {
      return rental.status === "pending";
    });
    var dueToday = active.filter(function (rental) {
      return rental.dueDate === todayLocal();
    });
    $("adminTotalRentals").textContent = state.myLoans.length;
    $("adminActiveRentals").textContent = active.length;
    $("adminPendingRentals").textContent = pending.length;
    $("adminDueTodayRentals").textContent = dueToday.length;
  }

  function updateReturnOptions() {
    var select = $("retLoan");
    if (!select) return;
    var options = '<option value="">-- Select an active rental --</option>';
    for (var i = 0; i < state.myLoans.length; i++) {
      var rental = state.myLoans[i];
      if (rental.status !== "active") continue;
      options += '<option value="' + escapeHtml(rental.id) + '">LN-' + escapeHtml(rental.id) + ': ' +
        escapeHtml(rental.student || state.user.name) + " — " + escapeHtml(rental.itemName) +
        " (₱" + escapeHtml(rental.deposit) + ")</option>";
    }
    select.innerHTML = options;
  }

  function openInventoryItem(item) {
    var form = $("inventoryItemForm");
    form.reset();
    $("inventoryItemId").value = item ? item.id : "";
    $("inventoryItemModalTitle").textContent = item ? "Edit Rental Item" : "Add Rental Item";
    if (item) {
      $("inventoryItemName").value = item.name;
      $("inventoryItemCategory").value = item.category;
      $("inventoryItemCondition").value = item.condition;
      $("inventoryItemDescription").value = item.desc;
      $("inventoryItemSpecs").value = item.specs.join("\n");
      $("inventoryItemRate").value = item.dailyRate;
      $("inventoryItemDeposit").value = item.deposit;
      $("inventoryItemStock").value = item.total;
    }
    showModal("inventoryItemModal");
    $("inventoryItemName").focus();
  }

  function openDamageReport(rentalId) {
    var select = $("damageRentalId");
    var options = "";
    for (var i = 0; i < state.myLoans.length; i++) {
      var rental = state.myLoans[i];
      options += '<option value="' + escapeHtml(rental.id) + '">' +
        "LN-" + escapeHtml(rental.id) + " · " + escapeHtml(rental.itemName) +
        (rental.student ? " · " + escapeHtml(rental.student) : "") +
        " (" + escapeHtml(rental.status) + ")</option>";
    }
    if (!options) {
      showToast("There are no rentals available to attach to this report.", "error");
      return;
    }
    $("damageReportForm").reset();
    select.innerHTML = options;
    if (rentalId) select.value = String(rentalId);
    showModal("damageReportModal");
    select.focus();
  }

  function openPaymentForm() {
    if (!state.myLoans.length) {
      showToast("Record a payment only after a rental exists.", "error");
      return;
    }
    $("paymentForm").reset();
    $("paymentRentalId").innerHTML = state.myLoans.map(function (rental) {
      return '<option value="' + escapeHtml(rental.id) + '">LN-' + escapeHtml(rental.id) +
        " · " + escapeHtml(rental.student || state.user.name) + " · " +
        escapeHtml(rental.itemName) + " (" + escapeHtml(rental.status) + ")</option>";
    }).join("");
    showModal("paymentModal");
    $("paymentRentalId").focus();
  }

  function updateNotifBadge(count) {
    var b = $("userNotifBadge");
    if (!b) return;
    if (count > 0) {
      b.textContent = count > 99 ? "99+" : count;
      b.classList.remove("hidden");
      b.classList.add("has-unread");
    } else {
      b.classList.add("hidden");
      b.classList.remove("has-unread");
    }
  }

  function fetchNotificationCount() {
    if (!state.loggedIn || state.adminMode) return;
    apiRequest("notifications").then(function (data) {
      var notifications = data.notifications || [];
      var unread = 0;
      for (var i = 0; i < notifications.length; i++) {
        if (Number(notifications[i].unread)) unread++;
      }
      updateNotifBadge(unread);
    }).catch(function () {});
  }

  function openUserNotifications() {
    updateNotifBadge(0);
    apiRequest("notifications").then(function (data) {
      var notifications = data.notifications || [];
      var list = $("userNotificationsList");
      list.innerHTML = notifications.length
        ? notifications.map(function (notice) {
          return '<article class="notification-entry' + (Number(notice.unread) ? " unread" : "") + '">' +
            "<strong>" + escapeHtml(notice.subject) + "</strong>" +
            "<p>" + escapeHtml(notice.message) + "</p>" +
            "<time>" + escapeHtml(notice.date) + "</time></article>";
        }).join("")
        : '<p class="empty-state">You have no notifications.</p>';
      showModal("userNotificationsModal");
      return apiRequest("notifications-read", { method: "PATCH" });
    }).catch(showRequestError);
  }


  function init() {
    renderHomeFeatured("all");
    loadInventory().catch(showRequestError);
    loadSettings().catch(showRequestError);
    apiRequest("me").then(function (data) {
      if (data.admin) {
        applyUser(data.admin);
        state.loggedIn = true;
        state.user = data.admin;
        enterAdmin();
      } else if (data.user) {
        loginUser(data.user);
        Promise.all([loadRentals(), loadSettings()]).catch(showRequestError);
      }
    }).catch(showRequestError);



    document.addEventListener("click", function (e) {
      var t = e.target;

      if (t.matches("[data-page]") || t.closest("[data-page]")) {
        var el = t.matches("[data-page]") ? t : t.closest("[data-page]");
        navigatePage(el.getAttribute("data-page"));
        return;
      }

      if (t.matches("[data-upage]") || t.closest("[data-upage]")) {
        var uel = t.matches("[data-upage]") ? t : t.closest("[data-upage]");
        navigatePage(uel.getAttribute("data-upage"));
        return;
      }

      if (t.matches("[data-av]") || t.closest("[data-av]")) {
        var ael = t.matches("[data-av]") ? t : t.closest("[data-av]");
        navigateAdmin(ael.getAttribute("data-av"));
        return;
      }

      if (t.matches("[data-jump]") || t.closest("[data-jump]")) {
        var jel = t.matches("[data-jump]") ? t : t.closest("[data-jump]");
        navigateAdmin(jel.getAttribute("data-jump"));
        return;
      }

      if (t.matches("[data-hcat]") || t.closest("[data-hcat]")) {
        var hel = t.matches("[data-hcat]") ? t : t.closest("[data-hcat]");
        var hcat = hel.getAttribute("data-hcat");
        var hchips = $$("#homeCatChips .chip");
        for (var hc = 0; hc < hchips.length; hc++) hchips[hc].classList.toggle("active", hchips[hc] === hel);
        renderHomeFeatured(hcat);
        return;
      }

      if (t.matches("[data-ccat]") || t.closest("[data-ccat]")) {
        var cel = t.matches("[data-ccat]") ? t : t.closest("[data-ccat]");
        var ccat = cel.getAttribute("data-ccat");
        var cchips = $$("#catalogCatChips .chip");
        for (var cc = 0; cc < cchips.length; cc++) cchips[cc].classList.toggle("active", cchips[cc] === cel);
        renderCatalog("catalogGrid", ccat, $("catalogSearch") ? $("catalogSearch").value : "");
        return;
      }

      if (t.matches("[data-bcat]") || t.closest("[data-bcat]")) {
        var bel = t.matches("[data-bcat]") ? t : t.closest("[data-bcat]");
        var bcat = bel.getAttribute("data-bcat");
        var bchips = $$("#browseCatChips .chip");
        for (var bc = 0; bc < bchips.length; bc++) bchips[bc].classList.toggle("active", bchips[bc] === bel);
        renderCatalog("browseGrid", bcat, $("browseSearch") ? $("browseSearch").value : "");
        return;
      }

      if (t.matches("[data-rent-id]") || t.closest("[data-rent-id]")) {
        var rel = t.matches("[data-rent-id]") ? t : t.closest("[data-rent-id]");
        openRentModal(rel.getAttribute("data-rent-id"));
        return;
      }

      if (t.matches("[data-edit-inventory]")) {
        var editItem = state.inventory.find(function (item) {
          return String(item.id) === t.getAttribute("data-edit-inventory");
        });
        if (editItem) openInventoryItem(editItem);
        return;
      }

      if (t.matches("[data-delete-inventory]")) {
        var deleteId = t.getAttribute("data-delete-inventory");
        if (!window.confirm("Delete this item from the rental inventory?")) return;
        apiRequest("inventory-delete&id=" + encodeURIComponent(deleteId), { method: "DELETE" })
          .then(loadInventory).catch(showRequestError);
        return;
      }

      if (t.matches("[data-review-request]") || t.closest("[data-review-request]")) {
        var reviewButton = t.matches("[data-review-request]") ? t : t.closest("[data-review-request]");
        var requestId = reviewButton.getAttribute("data-review-request");
        var decision = reviewButton.getAttribute("data-decision");
        apiRequest("rental-request", {
          method: "PATCH",
          body: { id: requestId, decision: decision }
        }).then(function () {
          showToast(decision === "approve" ? "Rental request approved." : "Rental request rejected; the student was notified.", "success");
          return Promise.all([loadRentals(), loadInventory()]);
        }).catch(showRequestError);
        return;
      }

      if (t.matches("[data-pickup-rental]")) {
        var pickupId = t.getAttribute("data-pickup-rental");
        apiRequest("rental-pickup", { method: "PATCH", body: { id: pickupId } })
          .then(function () {
            showToast("Payment verified and rental marked as picked up.", "success");
            return Promise.all([loadRentals(), loadInventory()]);
          }).catch(showRequestError);
        return;
      }

      if (t.matches("[data-return-rental]")) {
        var returnId = t.getAttribute("data-return-rental");
        apiRequest("rental-return", { method: "PATCH", body: { id: returnId } })
          .then(function () { return Promise.all([loadRentals(), loadInventory(), loadAdminUsers(), loadAdminOperations()]); })
          .catch(showRequestError);
        return;
      }

      if (t.matches("[data-change-role]") || t.closest("[data-change-role]")) {
        var roleButton = t.matches("[data-change-role]") ? t : t.closest("[data-change-role]");
        var accountId = roleButton.getAttribute("data-change-role");
        var nextRole = roleButton.getAttribute("data-next-role");
        var roleLabel = nextRole === "admin" ? "administrator" : "student";
        if (!window.confirm("Change this account's role to " + roleLabel + "?")) return;
        apiRequest("admin-role", {
          method: "PATCH",
          body: { userId: accountId, role: nextRole }
        }).then(function () {
          showToast("Account role updated.", "success");
          return loadAdminUsers();
        }).catch(showRequestError);
        return;
      }

      if (t.matches("[data-report-rental]") || t.closest("[data-report-rental]")) {
        var reportButton = t.matches("[data-report-rental]") ? t : t.closest("[data-report-rental]");
        openDamageReport(reportButton.getAttribute("data-report-rental"));
        return;
      }

      if (t.id === "btnOpenLogin") { showModal("loginModal"); return; }
      if (t.id === "btnOpenRegister") { showModal("registerModal"); return; }
      if (t.id === "btnCloseLogin") { hideModal("loginModal"); return; }
      if (t.id === "btnCloseRegister") { hideModal("registerModal"); return; }
      if (t.id === "btnCloseRent" || t.id === "btnCancelRent") { hideModal("rentModal"); return; }
      if (t.id === "btnSwitchToRegister") { hideModal("loginModal"); showModal("registerModal"); return; }
      if (t.id === "btnSwitchToLogin") { hideModal("registerModal"); showModal("loginModal"); return; }
      if (t.id === "btnUserLogout") { logoutUser(); return; }
      if (t.id === "btnHeroBrowse" || t.id === "btnViewAllCatalog" || t.id === "btnHomeViewAllCatalog") { navigatePage("catalog"); return; }
      if (t.id === "btnHeroLearn") { var hs = $("howSection"); if (hs) hs.scrollIntoView({ behavior: "smooth" }); return; }
      if (t.id === "btnDashRentKit" || t.id === "btnMyRentMore" || t.id === "btnHeaderQuickRent") {
        if (state.loggedIn) navigatePage("browse");
        else showModal("loginModal");
        return;
      }
      if (t.id === "btnDiscreetAdminPortal" || t.closest("#btnDiscreetAdminPortal") || t.id === "btnFooterAdmin" || (t.id === "footerCopyright" && e.detail >= 2)) {
        if (e.preventDefault) e.preventDefault();
        showModal("adminPassModal");
        return;
      }
      if (t.id === "btnCloseAdminPass") { hideModal("adminPassModal"); return; }
      if (t.id === "btnAddInventory") { openInventoryItem(null); return; }
      if (t.id === "btnCloseInventoryItem" || t.id === "btnCancelInventoryItem") { hideModal("inventoryItemModal"); return; }
      if (t.id === "btnLogIncident") { openDamageReport(null); return; }
      if (t.id === "btnCloseDamageReport" || t.id === "btnCancelDamageReport") { hideModal("damageReportModal"); return; }
      if (t.id === "btnRecordPayment") { openPaymentForm(); return; }
      if (t.id === "btnClosePayment" || t.id === "btnCancelPayment") { hideModal("paymentModal"); return; }
      if (t.id === "btnBroadcastOverdue" || t.id === "btnDispatchOverdue" || t.closest("#btnDispatchOverdue")) {
        if (!window.confirm("Send an in-app overdue warning to all students with overdue active rentals? This delivers to student inboxes.")) return;
        apiRequest("overdue-broadcast", { method: "POST" }).then(function (data) {
          showToast(data.sent
            ? "Overdue warnings dispatched to " + data.recipients + " student(s) for " + data.sent + " overdue rental(s)."
            : data.message, data.sent ? "success" : "info");
        }).catch(showRequestError);
        return;
      }
      if (t.id === "btnDispatchDueToday" || t.closest("#btnDispatchDueToday")) {
        if (!window.confirm("Send due today reminders to all students whose rentals are due today?")) return;
        apiRequest("due-today-broadcast", { method: "POST" }).then(function (data) {
          showToast(data.sent
            ? "Due today reminders dispatched to " + data.recipients + " student(s) for " + data.sent + " rental(s)."
            : data.message, data.sent ? "success" : "info");
        }).catch(showRequestError);
        return;
      }
      if (t.id === "btnDispatchDepositRefund" || t.closest("#btnDispatchDepositRefund")) {
        if (!window.confirm("Send deposit refund receipts/notices to students with returned rentals?")) return;
        apiRequest("deposit-refund-broadcast", { method: "POST" }).then(function (data) {
          showToast(data.sent
            ? "Deposit refund receipts sent to " + data.recipients + " student(s) for " + data.sent + " rental(s)."
            : data.message, data.sent ? "success" : "info");
        }).catch(showRequestError);
        return;
      }
      if (t.id === "userNotifBtn" || t.closest("#userNotifBtn")) { openUserNotifications(); return; }
      if (t.id === "btnCloseNotifications" || t.id === "btnDismissNotifications") {
        hideModal("userNotificationsModal");
        return;
      }
      if (t.id === "btnRefreshUsers") {
        loadAdminUsers().then(function () { showToast("Account list refreshed.", "success"); }).catch(showRequestError);
        return;
      }
      if (t.id === "btnExportReport") {
        var reportTable = $("reportContent").querySelector("table");
        if (!reportTable) {
          showToast("There is no report data to export.", "error");
          return;
        }
        var csvRows = Array.prototype.map.call(reportTable.rows, function (row) {
          return Array.prototype.map.call(row.cells, function (cell) {
            return '"' + cell.textContent.trim().replace(/"/g, '""') + '"';
          }).join(",");
        });
        var csv = "\uFEFF" + csvRows.join("\r\n");
        var downloadUrl = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
        var downloadLink = document.createElement("a");
        downloadLink.href = downloadUrl;
        downloadLink.download = "ctu-rental-" + state.currentReportTab + "-report.csv";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        downloadLink.remove();
        window.setTimeout(function () { URL.revokeObjectURL(downloadUrl); }, 1000);
        return;
      }
      if (t.id === "btnPrintReport") { window.print(); return; }
      if (t.id === "btnAdminExit") { exitAdmin(); return; }
      if (t.id === "headerExitAdminBtn") { exitAdmin(); return; }
      if (t.id === "mobileToggle") {
        var nl = $("navLinks");
        if (nl) nl.classList.toggle("open");
        return;
      }
      if (t.id === "navBrandHome" || t.id === "userBrandHome") {
        e.preventDefault();
        if (state.loggedIn) navigatePage("dashboard");
        else navigatePage("landing");
        return;
      }

      if (t.matches("[data-rtab]") || t.closest("[data-rtab]")) {
        var rtel = t.matches("[data-rtab]") ? t : t.closest("[data-rtab]");
        var rtabs = $$("#reportTabs .chip");
        for (var rt = 0; rt < rtabs.length; rt++) rtabs[rt].classList.toggle("active", rtabs[rt] === rtel);
        var tabName = rtel.getAttribute("data-rtab");
        renderReport(tabName);
        return;
      }

      if (t.closest(".modal-overlay") && !t.closest(".modal-card")) {
        t.closest(".modal-overlay").classList.add("hidden");
        return;
      }
    });

    if ($("loginForm")) {
      $("loginForm").addEventListener("submit", function (e) {
        e.preventDefault();
        apiRequest("login", {
          method: "POST",
          body: {
            identity: $("loginEmail").value.trim(),
            password: $("loginPass").value
          }
        }).then(function () {
          hideModal("loginModal");
          if (data.admin) {
            applyUser(data.admin);
            state.loggedIn = true;
            state.user = data.admin;
            enterAdmin();
            showToast("Welcome to Administrator Suite, " + data.admin.name + "!", "success");
            return;
          }
          loginUser(data.user);
          Promise.all([loadRentals(), loadSettings()]).catch(showRequestError);
          showToast("Welcome back, " + data.user.name + "!", "success");
        }).catch(showRequestError);
      });
    }

    if ($("registerForm")) {
      $("registerForm").addEventListener("submit", function (e) {
        e.preventDefault();
        if ($("regPass").value !== $("regConfirm").value) {
          showToast("Passwords do not match.", "error");
          return;
        }
        apiRequest("register", {
          method: "POST",
          body: {
            name: $("regName").value.trim(),
            studentId: $("regSid").value.trim(),
            email: $("regEmail").value.trim(),
            phone: $("regPhone").value.trim(),
            school: $("regSchool").value.trim(),
            program: $("regProgram").value.trim(),
            password: $("regPass").value
          }
        }).then(function (data) {
          hideModal("registerModal");
          loginUser(data.user);
          Promise.all([loadRentals(), loadSettings()]).catch(showRequestError);
          showToast("Account created successfully.", "success");
        }).catch(showRequestError);
      });
    }

    if ($("adminPassForm")) {
      $("adminPassForm").addEventListener("submit", function (e) {
        e.preventDefault();
        apiRequest("admin-login", {
          method: "POST",
          body: {
            identity: $("adminEmailInput").value.trim(),
            password: $("adminPassInput").value
          }
        }).then(function (data) {
          hideModal("adminPassModal");
          applyUser(data.admin);
          state.loggedIn = true;
          state.user = data.admin;
          enterAdmin();
          showToast("Welcome to Administrator Suite, " + data.admin.name + "!", "success");
        }).catch(showRequestError);
      });
    }

    if ($("rentForm")) {
      $("rentForm").addEventListener("submit", function (e) {
        e.preventDefault();
        var submitButton = document.querySelector("#rentForm button[type='submit']");
        if (submitButton) submitButton.disabled = true;
        var itemId = $("rentItemId").value;
        var item = null;
        for (var i = 0; i < state.inventory.length; i++) {
          if (state.inventory[i].id === itemId) { item = state.inventory[i]; break; }
        }
        if (!item) return;

        if (!state.loggedIn) {
          hideModal("rentModal");
          showModal("loginModal");
          showToast("Please log in to complete your rental.", "info");
          return;
        }

        var days = parseInt($("rentDays").value, 10);
        apiRequest("rentals", {
          method: "POST",
          body: {
            itemId: item.id,
            startDate: $("rentStartDate").value,
            days: days,
            paymentMethod: $("rentPay").value
          }
        }).then(function () {
          hideModal("rentModal");
          showToast("Rental request recorded for " + item.name + ". Awaiting administrator review.", "success");
          return Promise.all([loadRentals(), loadInventory(), loadAdminOperations()]);
        }).catch(function (error) {
          showRequestError(error);
          updateRentAvailability();
        });
      });
    }

    if ($("inventoryItemForm")) {
      $("inventoryItemForm").addEventListener("submit", function (e) {
        e.preventDefault();
        var categorySelect = $("inventoryItemCategory");
        var id = $("inventoryItemId").value;
        var payload = {
          name: $("inventoryItemName").value.trim(),
          category: categorySelect.value,
          catLabel: categorySelect.options[categorySelect.selectedIndex].textContent,
          condition: $("inventoryItemCondition").value,
          desc: $("inventoryItemDescription").value.trim(),
          specs: $("inventoryItemSpecs").value.split(/\r?\n/).map(function (spec) { return spec.trim(); }).filter(Boolean),
          dailyRate: Number($("inventoryItemRate").value),
          deposit: Number($("inventoryItemDeposit").value),
          total: Number($("inventoryItemStock").value)
        };
        var action = id ? "inventory-update&id=" + encodeURIComponent(id) : "inventory";
        apiRequest(action, { method: id ? "PUT" : "POST", body: payload }).then(function () {
          hideModal("inventoryItemModal");
          showToast("Inventory item saved.", "success");
          return loadInventory();
        }).catch(showRequestError);
      });
    }

    if ($("damageReportForm")) {
      $("damageReportForm").addEventListener("submit", function (e) {
        e.preventDefault();
        var estimatedCost = $("damageEstimatedCost").value;
        apiRequest("damage-reports", {
          method: "POST",
          body: {
            rentalId: $("damageRentalId").value,
            type: $("damageType").value,
            description: $("damageDescription").value.trim(),
            estimatedCost: estimatedCost === "" ? null : Number(estimatedCost)
          }
        }).then(function () {
          hideModal("damageReportModal");
          showToast("Damage/loss report submitted for staff review.", "success");
          if (state.adminMode) return loadDamageReports();
        }).catch(showRequestError);
      });
    }

    if ($("paymentForm")) {
      $("paymentForm").addEventListener("submit", function (e) {
        e.preventDefault();
        apiRequest("payments", {
          method: "POST",
          body: {
            rentalId: $("paymentRentalId").value,
            type: $("paymentType").value,
            amount: Number($("paymentAmount").value),
            method: $("paymentMethod").value,
            reference: $("paymentReference").value.trim()
          }
        }).then(function () {
          hideModal("paymentModal");
          showToast("Payment record saved.", "success");
          return loadAdminOperations();
        }).catch(showRequestError);
      });
    }

    if ($("rentDays")) {
      $("rentDays").addEventListener("input", function () {
        var itemId = $("rentItemId").value;
        var item = null;
        for (var i = 0; i < state.inventory.length; i++) {
          if (state.inventory[i].id === itemId) { item = state.inventory[i]; break; }
        }
        if (item) updateRentCost(item);
        updateRentAvailability();
      });
    }

    if ($("rentStartDate")) {
      $("rentStartDate").addEventListener("change", function () {
        var item = state.inventory.find(function (inventoryItem) {
          return inventoryItem.id === $("rentItemId").value;
        });
        if (item) updateRentCost(item);
        updateRentAvailability();
      });
    }

    if ($("catalogSearch")) {
      $("catalogSearch").addEventListener("input", function () {
        var activeChip = document.querySelector("#catalogCatChips .chip.active");
        var cat = activeChip ? activeChip.getAttribute("data-ccat") : "all";
        renderCatalog("catalogGrid", cat, this.value);
      });
    }

    if ($("browseSearch")) {
      $("browseSearch").addEventListener("input", function () {
        var activeChip = document.querySelector("#browseCatChips .chip.active");
        var cat = activeChip ? activeChip.getAttribute("data-bcat") : "all";
        renderCatalog("browseGrid", cat, this.value);
      });
    }

    if ($("returnForm")) {
      $("returnForm").addEventListener("submit", function (e) {
        e.preventDefault();
        if (!$("retLoan").value) {
          showToast("Select an active rental first.", "error");
          return;
        }
        apiRequest("rental-return", {
          method: "PATCH",
          body: {
            id: $("retLoan").value,
            condition: $("retCondition").value,
            notes: $("retNotes").value.trim()
          }
        })
          .then(function () {
            showToast("Return recorded.", "success");
            $("returnForm").reset();
            return Promise.all([loadRentals(), loadInventory(), loadAdminUsers(), loadAdminOperations()]);
          }).catch(showRequestError);
      });
    }

    if ($("settingsForm")) {
      $("settingsForm").addEventListener("submit", function (e) {
        e.preventDefault();
        apiRequest("settings", {
          method: "PUT",
          body: {
            overdueRate: Number($("sOverdue").value),
            maxDuration: Number($("sMaxDays").value),
            depositPercent: Number($("sDepPct").value)
          }
        }).then(function () {
          showToast("System settings saved successfully.", "success");
          return loadSettings();
        }).catch(showRequestError);
      });
    }

    if ($("customNotifForm")) {
      $("customNotifForm").addEventListener("submit", function (e) {
        e.preventDefault();
        var recipient = $("notifTo").value.trim();
        var subject = $("notifSubj").value.trim();
        var message = $("notifMsg").value.trim();
        if (!subject || !message) {
          showToast("Please enter both a subject and message.", "error");
          return;
        }
        apiRequest("custom-notification", {
          method: "POST",
          body: {
            recipient: recipient || "ALL",
            subject: subject,
            message: message
          }
        }).then(function (data) {
          $("customNotifForm").reset();
          showToast(data.message || "Custom notification sent successfully.", "success");
        }).catch(showRequestError);
      });
    }

    var navLogoIconEl = $("navLogoIcon");
    if (navLogoIconEl) {
      navLogoIconEl.addEventListener("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        showModal("adminPassModal");
      });
    }

    function checkAdminHash() {
      if (window.location.hash === "#admin" || window.location.hash === "#/admin" || window.location.hash === "#admin-portal") {
        showModal("adminPassModal");
      }
    }
    checkAdminHash();
    window.addEventListener("hashchange", checkAdminHash);

    document.addEventListener("keydown", function (e) {
      if (
        (e.altKey && (e.key === "a" || e.key === "A")) ||
        (e.ctrlKey && e.altKey && (e.key === "a" || e.key === "A")) ||
        ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === "A" || e.key === "a"))
      ) {
        if (e.preventDefault) e.preventDefault();
        showModal("adminPassModal");
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
