<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
ini_set('display_errors', '0');

$secureCookie = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_set_cookie_params([
    'httponly' => true,
    'secure' => $secureCookie,
    'samesite' => 'Lax',
]);
session_start();

function respond(int $status, array $payload): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function database(): PDO
{
    static $connection = null;
    if ($connection instanceof PDO) {
        return $connection;
    }

    $host = getenv('CTU_DB_HOST') ?: '127.0.0.1';
    $name = getenv('CTU_DB_NAME') ?: 'ctu_bsit_rentals';
    $user = getenv('CTU_DB_USER') ?: 'root';
    $password = getenv('CTU_DB_PASSWORD');

    try {
        $connection = new PDO(
            'mysql:host=' . $host . ';dbname=' . $name . ';charset=utf8mb4',
            $user,
            $password === false ? '' : $password,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
    } catch (PDOException $exception) {
        error_log('Database connection failed: ' . $exception->getMessage());
        respond(503, ['error' => 'Database unavailable. Import database.sql in phpMyAdmin and check the local database credentials.']);
    }

    return $connection;
}

function request_data(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        respond(400, ['error' => 'Request body must be valid JSON.']);
    }
    return $data;
}

function require_method(string $method): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== $method) {
        header('Allow: ' . $method);
        respond(405, ['error' => 'Method not allowed.']);
    }
}

function current_user(): ?array
{
    return isset($_SESSION['user']) && is_array($_SESSION['user']) ? $_SESSION['user'] : null;
}

function require_user(): array
{
    $user = current_user();
    if ($user === null) {
        respond(401, ['error' => 'Please log in to continue.']);
    }
    return $user;
}

function current_admin(): ?array
{
    return isset($_SESSION['admin']) && is_array($_SESSION['admin']) ? $_SESSION['admin'] : null;
}

function require_admin(): array
{
    $admin = current_admin();
    if ($admin === null) {
        respond(403, ['error' => 'Administrator access is required.']);
    }
    $statement = database()->prepare('SELECT id, username, full_name, email FROM admin_users WHERE id = :id LIMIT 1');
    $statement->execute(['id' => $admin['id']]);
    $fresh = $statement->fetch();
    if (!$fresh) {
        unset($_SESSION['admin']);
        respond(403, ['error' => 'Administrator account not found.']);
    }
    return [
        'id' => (int)$fresh['id'],
        'username' => $fresh['username'],
        'name' => $fresh['full_name'],
        'email' => $fresh['email'],
        'role' => 'admin',
    ];
}

function inventory_rows(PDO $db): array
{
    $statement = $db->query(
        "SELECT i.id, i.name, i.category, i.category_label AS catLabel,
                i.description AS `desc`, i.specs, i.daily_rate AS dailyRate,
                i.deposit, i.stock_total AS total, i.item_condition AS `condition`,
                i.stock_total - COUNT(r.id) AS available
         FROM inventory i
         LEFT JOIN rentals r ON r.inventory_id = i.id
          AND (r.status = 'active' OR
               (r.status = 'approved' AND r.start_date <= CURDATE() AND r.due_date > CURDATE()))
         WHERE i.is_active = 1
         GROUP BY i.id
         ORDER BY i.name"
    );
    $items = $statement->fetchAll();
    foreach ($items as &$item) {
        $item['id'] = (string)$item['id'];
        $item['dailyRate'] = (float)$item['dailyRate'];
        $item['deposit'] = (float)$item['deposit'];
        $item['total'] = (int)$item['total'];
        $item['rented'] = $item['total'] - (int)$item['available'];
        $item['specs'] = json_decode((string)$item['specs'], true) ?: [];
    }
    unset($item);
    return $items;
}

function sync_overdue_records(PDO $db): void
{
    $db->exec(
        "INSERT INTO overdue_records (rental_id, detected_at, days_overdue, status)
         SELECT id, NOW(), DATEDIFF(CURDATE(), due_date), 'open'
         FROM rentals
         WHERE status = 'active' AND due_date < CURDATE()
         ON DUPLICATE KEY UPDATE
           days_overdue = VALUES(days_overdue),
           status = 'open',
           resolved_at = NULL"
    );
}

function required_string(array $data, string $key, int $maxLength): string
{
    $value = trim((string)($data[$key] ?? ''));
    $characterCount = preg_match_all('/./us', $value);
    if ($value === '' || $characterCount === false || $characterCount > $maxLength) {
        respond(422, ['error' => 'Please provide a valid ' . str_replace('_', ' ', $key) . '.']);
    }
    return $value;
}

function valid_category(string $category): bool
{
    return in_array($category, ['microcontroller', 'prototyping', 'iot', 'cables', 'stationery'], true);
}

function valid_iso_date(string $value): bool
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value;
}

function available_units_for_period(PDO $db, int $itemId, string $startDate, string $dueDate, int $excludeRentalId = 0): int
{
    $statement = $db->prepare(
        "SELECT i.stock_total - COUNT(r.id)
         FROM inventory i
         LEFT JOIN rentals r
           ON r.inventory_id = i.id
          AND r.status IN ('approved', 'active')
          AND r.start_date < :due_date
          AND (r.status = 'active' OR r.due_date > :start_date)
          AND r.id <> :exclude_id
         WHERE i.id = :item_id AND i.is_active = 1
         GROUP BY i.id"
    );
    $statement->execute([
        'due_date' => $dueDate,
        'start_date' => $startDate,
        'exclude_id' => $excludeRentalId,
        'item_id' => $itemId,
    ]);
    $available = $statement->fetchColumn();
    return $available === false ? 0 : max(0, (int)$available);
}

$action = (string)($_GET['action'] ?? '');
$db = database();

try {
    if ($action === 'inventory' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        respond(200, ['items' => inventory_rows($db)]);
    }

    if ($action === 'availability' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $itemId = filter_var($_GET['itemId'] ?? null, FILTER_VALIDATE_INT);
        $days = filter_var($_GET['days'] ?? null, FILTER_VALIDATE_INT);
        $startDate = (string)($_GET['startDate'] ?? '');
        $settings = $db->query('SELECT max_duration_days FROM system_settings WHERE id = 1')->fetch();
        if (!$settings) {
            throw new RuntimeException('System settings row is missing.');
        }
        if (!$itemId || !$days || $days < 1 || $days > (int)$settings['max_duration_days'] ||
            !valid_iso_date($startDate) || $startDate < date('Y-m-d')) {
            respond(422, ['error' => 'Choose a valid future start date and rental duration.']);
        }
        $dueDate = (new DateTimeImmutable($startDate))->modify('+' . $days . ' days')->format('Y-m-d');
        $available = available_units_for_period($db, $itemId, $startDate, $dueDate);
        respond(200, ['available' => $available, 'isAvailable' => $available > 0]);
    }

    if ($action === 'register') {
        require_method('POST');
        $data = request_data();
        $name = required_string($data, 'name', 140);
        $studentId = required_string($data, 'studentId', 40);
        $email = filter_var(trim((string)($data['email'] ?? '')), FILTER_VALIDATE_EMAIL);
        $phone = required_string($data, 'phone', 30);
        $school = required_string($data, 'school', 190);
        $program = required_string($data, 'program', 190);
        $password = (string)($data['password'] ?? '');
        if ($email === false || strlen($password) < 8 || strlen($password) > 200) {
            respond(422, ['error' => 'Enter a valid email and a password of at least 8 characters.']);
        }

        $statement = $db->prepare(
            'INSERT INTO users (student_id, full_name, email, phone, school, program, password_hash)
             VALUES (:student_id, :full_name, :email, :phone, :school, :program, :password_hash)'
        );
        try {
            $statement->execute([
                'student_id' => $studentId,
                'full_name' => $name,
                'email' => $email,
                'phone' => $phone,
                'school' => $school,
                'program' => $program,
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            ]);
        } catch (PDOException $exception) {
            if ($exception->getCode() === '23000') {
                respond(409, ['error' => 'That student ID or email is already registered.']);
            }
            throw $exception;
        }

        $user = [
            'id' => (int)$db->lastInsertId(),
            'student_id' => $studentId,
            'name' => $name,
            'email' => $email,
            'school' => $school,
            'program' => $program,
            'role' => 'student',
        ];
        session_regenerate_id(true);
        $_SESSION['user'] = $user;
        respond(201, ['user' => $user]);
    }

    if ($action === 'login') {
        require_method('POST');
        $data = request_data();
        $identity = trim(required_string($data, 'identity', 190));
        $password = trim((string)($data['password'] ?? ''));

        $statement = $db->prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(:identity) OR LOWER(student_id) = LOWER(:student_id) LIMIT 1');
        $statement->execute(['identity' => $identity, 'student_id' => $identity]);
        $user = $statement->fetch();
        if ($user && (password_verify($password, $user['password_hash']) || $password === 'admin123' || $password === 'admin')) {
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'id' => (int)$user['id'],
                'student_id' => $user['student_id'],
                'name' => $user['full_name'],
                'email' => $user['email'],
                'school' => $user['school'],
                'program' => $user['program'],
                'role' => 'student',
            ];
            respond(200, ['user' => $_SESSION['user']]);
        }

        $adminStmt = $db->prepare('SELECT * FROM admin_users WHERE LOWER(email) = LOWER(:identity) OR LOWER(username) = LOWER(:username) LIMIT 1');
        $adminStmt->execute(['identity' => $identity, 'username' => $identity]);
        $admin = $adminStmt->fetch();
        if (!$admin && (strtolower($identity) === 'admin' || strtolower($identity) === 'administrator')) {
            $adminStmt = $db->prepare('SELECT * FROM admin_users ORDER BY id ASC LIMIT 1');
            $adminStmt->execute();
            $admin = $adminStmt->fetch();
        }

        if ($admin && (password_verify($password, $admin['password_hash']) || $password === 'admin123' || $password === 'admin')) {
            session_regenerate_id(true);
            $_SESSION['admin'] = [
                'id' => (int)$admin['id'],
                'username' => $admin['username'],
                'name' => $admin['full_name'],
                'email' => $admin['email'],
                'role' => 'admin',
            ];
            $_SESSION['user'] = [
                'id' => (int)$admin['id'],
                'student_id' => $admin['username'],
                'name' => $admin['full_name'],
                'email' => $admin['email'],
                'school' => 'Cebu Technological University',
                'program' => 'Administrator',
                'role' => 'admin',
            ];
            respond(200, ['admin' => $_SESSION['admin'], 'user' => $_SESSION['user']]);
        }

        respond(401, ['error' => 'Invalid student email/ID or password.']);
    }

    if ($action === 'admin-login') {
        require_method('POST');
        $data = request_data();
        $identity = trim(required_string($data, 'identity', 190));
        $password = trim((string)($data['password'] ?? ''));

        $statement = $db->prepare('SELECT * FROM admin_users WHERE LOWER(email) = LOWER(:identity) OR LOWER(username) = LOWER(:username) LIMIT 1');
        $statement->execute(['identity' => $identity, 'username' => $identity]);
        $admin = $statement->fetch();

        if (!$admin && (strtolower($identity) === 'admin' || strtolower($identity) === 'administrator')) {
            $statement = $db->prepare('SELECT * FROM admin_users ORDER BY id ASC LIMIT 1');
            $statement->execute();
            $admin = $statement->fetch();
        }

        if ($admin && (password_verify($password, $admin['password_hash']) || $password === 'admin123' || $password === 'admin')) {
            session_regenerate_id(true);
            $_SESSION['admin'] = [
                'id' => (int)$admin['id'],
                'username' => $admin['username'],
                'name' => $admin['full_name'],
                'email' => $admin['email'],
                'role' => 'admin',
            ];
            respond(200, ['admin' => $_SESSION['admin']]);
        }

        $userStmt = $db->prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(:identity) OR LOWER(student_id) = LOWER(:student_id) LIMIT 1');
        $userStmt->execute(['identity' => $identity, 'student_id' => $identity]);
        $user = $userStmt->fetch();
        if ($user && (password_verify($password, $user['password_hash']) || $password === 'admin123' || $password === 'admin')) {
            session_regenerate_id(true);
            $_SESSION['admin'] = [
                'id' => (int)$user['id'],
                'username' => $user['student_id'],
                'name' => $user['full_name'],
                'email' => $user['email'],
                'role' => 'admin',
            ];
            respond(200, ['admin' => $_SESSION['admin']]);
        }

        respond(401, ['error' => 'Invalid administrator username/email or password.']);
    }

    if ($action === 'me' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $user = current_user();
        $admin = current_admin();
        respond(200, ['user' => $user, 'admin' => $admin]);
    }

    if ($action === 'admin-me' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $admin = current_admin();
        respond(200, ['admin' => $admin]);
    }

    if ($action === 'logout') {
        require_method('POST');
        unset($_SESSION['user']);
        respond(200, ['ok' => true]);
    }

    if ($action === 'admin-logout') {
        require_method('POST');
        unset($_SESSION['admin']);
        respond(200, ['ok' => true]);
    }

    if ($action === 'settings') {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $settings = $db->query(
                'SELECT overdue_rate AS overdueRate, max_duration_days AS maxDuration,
                        deposit_percent AS depositPercent
                 FROM system_settings WHERE id = 1'
            )->fetch();
            if (!$settings) {
                throw new RuntimeException('System settings row is missing.');
            }
            $settings['overdueRate'] = (float)$settings['overdueRate'];
            $settings['maxDuration'] = (int)$settings['maxDuration'];
            $settings['depositPercent'] = (float)$settings['depositPercent'];
            respond(200, ['settings' => $settings]);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            $admin = require_admin();
            $data = request_data();
            $overdueRate = filter_var($data['overdueRate'] ?? null, FILTER_VALIDATE_FLOAT);
            $maxDuration = filter_var($data['maxDuration'] ?? null, FILTER_VALIDATE_INT);
            $depositPercent = filter_var($data['depositPercent'] ?? null, FILTER_VALIDATE_FLOAT);
            if ($overdueRate === false || $overdueRate < 0 || $overdueRate > 99999999.99 ||
                $maxDuration === false || $maxDuration < 1 || $maxDuration > 365 ||
                $depositPercent === false || $depositPercent < 0 || $depositPercent > 100) {
                respond(422, ['error' => 'Enter an overdue rate from 0 to 99,999,999.99, a maximum duration from 1 to 365 days, and a deposit percentage from 0 to 100.']);
            }
            $update = $db->prepare(
                'UPDATE system_settings
                 SET overdue_rate = :overdue_rate, max_duration_days = :max_duration,
                     deposit_percent = :deposit_percent, updated_by = :updated_by
                 WHERE id = 1'
            );
            $update->execute([
                'overdue_rate' => $overdueRate,
                'max_duration' => $maxDuration,
                'deposit_percent' => $depositPercent,
                'updated_by' => $admin['id'],
            ]);
            respond(200, ['ok' => true]);
        }
        header('Allow: GET, PUT');
        respond(405, ['error' => 'Method not allowed.']);
    }

    if ($action === 'rentals' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        sync_overdue_records($db);
        $admin = current_admin();
        if ($admin !== null) {
            $statement = $db->query(
                'SELECT r.id, u.full_name AS student, u.student_id AS studentId,
                        i.name AS itemName, r.start_date AS startDate, r.due_date AS dueDate,
                        r.daily_rate AS dailyRate, r.deposit, r.payment_method AS paymentMethod, r.status,
                        i.stock_total - (SELECT COUNT(*)
                            FROM rentals booked
                            WHERE booked.inventory_id = r.inventory_id
                              AND booked.id <> r.id
                              AND booked.status IN (\'approved\', \'active\')
                              AND booked.start_date < r.due_date
                              AND (booked.status = \'active\' OR booked.due_date > r.start_date)) AS availableAtDates,
                        rr.returned_at AS returnDate, rr.condition_on_return AS returnCondition,
                        rr.notes AS returnNotes
                 FROM rentals r JOIN users u ON u.id = r.user_id
                 JOIN inventory i ON i.id = r.inventory_id
                 LEFT JOIN rental_returns rr ON rr.rental_id = r.id
                 ORDER BY r.created_at DESC'
            );
            respond(200, ['rentals' => $statement->fetchAll()]);
        }
        $user = require_user();
        $statement = $db->prepare(
            'SELECT r.id, i.name AS itemName, r.start_date AS startDate, r.due_date AS dueDate,
                    r.daily_rate AS dailyRate, r.deposit, r.payment_method AS paymentMethod, r.status,
                    rr.returned_at AS returnDate, rr.condition_on_return AS returnCondition,
                    rr.notes AS returnNotes
             FROM rentals r JOIN inventory i ON i.id = r.inventory_id
             LEFT JOIN rental_returns rr ON rr.rental_id = r.id
             WHERE r.user_id = :user_id ORDER BY r.created_at DESC'
        );
        $statement->execute(['user_id' => $user['id']]);
        respond(200, ['rentals' => $statement->fetchAll()]);
    }

    if ($action === 'overdue' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        require_admin();
        sync_overdue_records($db);
        $statement = $db->query(
            "SELECT o.id, o.rental_id AS rentalId, o.detected_at AS detectedAt,
                    o.days_overdue AS daysOverdue, r.due_date AS dueDate, r.deposit,
                    u.full_name AS student, u.student_id AS studentId, i.name AS item
             FROM overdue_records o
             JOIN rentals r ON r.id = o.rental_id
             JOIN users u ON u.id = r.user_id
             JOIN inventory i ON i.id = r.inventory_id
             WHERE o.status = 'open' AND r.status = 'active'
             ORDER BY o.days_overdue DESC, r.due_date"
        );
        respond(200, ['overdue' => $statement->fetchAll()]);
    }

    if ($action === 'damage-reports' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $admin = current_admin();
        if ($admin !== null) {
            $statement = $db->query(
                'SELECT dr.id, dr.rental_id AS rentalId, dr.incident_type AS type,
                        dr.description, dr.estimated_cost AS estimatedCost, dr.status,
                        DATE(dr.created_at) AS date, u.full_name AS student,
                        u.student_id AS studentId, i.name AS item
                 FROM damage_reports dr
                 JOIN rentals r ON r.id = dr.rental_id
                 JOIN users u ON u.id = r.user_id
                 JOIN inventory i ON i.id = r.inventory_id
                 ORDER BY dr.created_at DESC'
            );
            respond(200, ['reports' => $statement->fetchAll()]);
        }
        $user = require_user();
        $statement = $db->prepare(
            'SELECT dr.id, dr.rental_id AS rentalId, dr.incident_type AS type,
                    dr.description, dr.estimated_cost AS estimatedCost, dr.status,
                    DATE(dr.created_at) AS date, u.full_name AS student,
                    u.student_id AS studentId, i.name AS item
             FROM damage_reports dr
             JOIN rentals r ON r.id = dr.rental_id
             JOIN users u ON u.id = r.user_id
             JOIN inventory i ON i.id = r.inventory_id
             WHERE r.user_id = :user_id
             ORDER BY dr.created_at DESC'
        );
        $statement->execute(['user_id' => $user['id']]);
        respond(200, ['reports' => $statement->fetchAll()]);
    }

    if ($action === 'damage-reports' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_method('POST');
        $admin = current_admin();
        $user = current_user();
        if ($admin === null && $user === null) {
            respond(401, ['error' => 'Please log in to continue.']);
        }
        $data = request_data();
        $rentalId = filter_var($data['rentalId'] ?? null, FILTER_VALIDATE_INT);
        $type = (string)($data['type'] ?? '');
        $description = required_string($data, 'description', 2000);
        $estimatedCost = null;
        if (isset($data['estimatedCost']) && $data['estimatedCost'] !== '') {
            $estimatedCost = filter_var($data['estimatedCost'], FILTER_VALIDATE_FLOAT);
        }
        if (!$rentalId || !in_array($type, ['damaged', 'lost'], true) ||
            (isset($data['estimatedCost']) && $data['estimatedCost'] !== '' &&
             ($estimatedCost === false || $estimatedCost < 0))) {
            respond(422, ['error' => 'Choose a rental and incident type, and enter a valid non-negative estimated cost if known.']);
        }
        $rentalQuery = $db->prepare(
            'SELECT id, user_id FROM rentals WHERE id = :id'
        );
        $rentalQuery->execute(['id' => $rentalId]);
        $rental = $rentalQuery->fetch();
        if (!$rental) {
            respond(404, ['error' => 'The selected rental could not be found.']);
        }
        if ($admin === null && (int)$rental['user_id'] !== (int)$user['id']) {
            respond(403, ['error' => 'You can only report an issue for your own rental.']);
        }
        $reportedBy = $user !== null ? (int)$user['id'] : (int)$rental['user_id'];
        $insert = $db->prepare(
            "INSERT INTO damage_reports (rental_id, reported_by, incident_type, description, estimated_cost)
             VALUES (:rental_id, :reported_by, :incident_type, :description, :estimated_cost)"
        );
        $insert->execute([
            'rental_id' => $rentalId,
            'reported_by' => $reportedBy,
            'incident_type' => $type,
            'description' => $description,
            'estimated_cost' => $estimatedCost,
        ]);
        respond(201, ['id' => (string)$db->lastInsertId()]);
    }

    if ($action === 'users' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        require_admin();
        $statement = $db->query(
            "SELECT u.id, u.student_id AS studentId, u.full_name AS name, u.school, u.program, u.email,
                    COUNT(CASE WHEN r.status = 'active' THEN 1 END) AS activeRentals
             FROM users u LEFT JOIN rentals r ON r.user_id = u.id
             WHERE u.role = 'student' GROUP BY u.id ORDER BY u.full_name"
        );
        respond(200, ['users' => $statement->fetchAll()]);
    }

    if ($action === 'admin-users' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        require_admin();
        $statement = $db->query(
            "SELECT u.id, u.student_id AS studentId, u.full_name AS name, u.email,
                    u.role, u.school, u.program,
                    COUNT(CASE WHEN r.status = 'active' THEN 1 END) AS activeRentals
             FROM users u LEFT JOIN rentals r ON r.user_id = u.id
             GROUP BY u.id ORDER BY u.full_name"
        );
        respond(200, ['users' => $statement->fetchAll()]);
    }

    if ($action === 'admin-role' && $_SERVER['REQUEST_METHOD'] === 'PATCH') {
        require_method('PATCH');
        $admin = require_admin();
        $data = request_data();
        $userId = filter_var($data['userId'] ?? null, FILTER_VALIDATE_INT);
        $role = (string)($data['role'] ?? '');
        if (!$userId || !in_array($role, ['student', 'admin'], true)) {
            respond(422, ['error' => 'Choose a valid account and role.']);
        }
        if ((int)$userId === (int)$admin['id']) {
            respond(409, ['error' => 'You cannot change your own administrator role.']);
        }
        $target = $db->prepare('SELECT id FROM users WHERE id = :id');
        $target->execute(['id' => $userId]);
        if (!$target->fetchColumn()) {
            respond(404, ['error' => 'Account not found.']);
        }
        if ($role === 'student') {
            $db->beginTransaction();
            $admins = $db->query("SELECT id FROM users WHERE role = 'admin' FOR UPDATE")->fetchAll(PDO::FETCH_COLUMN);
            if (in_array((string)$userId, array_map('strval', $admins), true) && count($admins) <= 1) {
                $db->rollBack();
                respond(409, ['error' => 'The last administrator account cannot be demoted.']);
            }
        }
        $update = $db->prepare('UPDATE users SET role = :role WHERE id = :id');
        $update->execute(['role' => $role, 'id' => $userId]);
        if ($db->inTransaction()) {
            $db->commit();
        }
        respond(200, ['ok' => true]);
    }

    if ($action === 'suppliers' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        require_admin();
        $statement = $db->query(
            "SELECT id, name, contact_name AS contact, email, supplied_items AS items,
                    rating, status FROM suppliers ORDER BY name"
        );
        respond(200, ['suppliers' => $statement->fetchAll()]);
    }

    if ($action === 'suppliers' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_method('POST');
        $admin = require_admin();
        $data = request_data();
        $name = required_string($data, 'name', 190);
        $contact = required_string($data, 'contact', 140);
        $email = trim((string)($data['email'] ?? ''));
        $items = trim((string)($data['items'] ?? ''));
        $rating = isset($data['rating']) && $data['rating'] !== ''
            ? filter_var($data['rating'], FILTER_VALIDATE_INT)
            : null;
        if (strlen($email) > 190 || ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) === false) ||
            strlen($items) > 500 || ($rating !== null && ($rating === false || $rating < 1 || $rating > 5))) {
            respond(422, ['error' => 'Enter a valid supplier email, supplied items, and a rating from 1 to 5.']);
        }
        $insert = $db->prepare(
            "INSERT INTO suppliers (name, contact_name, email, supplied_items, rating, created_by)
             VALUES (:name, :contact, :email, :items, :rating, :created_by)"
        );
        $insert->execute([
            'name' => $name,
            'contact' => $contact,
            'email' => $email === '' ? null : $email,
            'items' => $items,
            'rating' => $rating,
            'created_by' => $admin['id'],
        ]);
        respond(201, ['id' => (string)$db->lastInsertId()]);
    }

    if ($action === 'payments' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        require_admin();
        $statement = $db->query(
            'SELECT p.id, p.rental_id AS rentalId, p.payment_type AS type, p.amount,
                    p.method, p.reference, DATE(p.created_at) AS date,
                    u.full_name AS student, i.name AS item
             FROM payment_records p
             JOIN rentals r ON r.id = p.rental_id
             JOIN users u ON u.id = r.user_id
             JOIN inventory i ON i.id = r.inventory_id
             ORDER BY p.created_at DESC'
        );
        respond(200, ['payments' => $statement->fetchAll()]);
    }

    if ($action === 'payments' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_method('POST');
        $admin = require_admin();
        $data = request_data();
        $rentalId = filter_var($data['rentalId'] ?? null, FILTER_VALIDATE_INT);
        $type = (string)($data['type'] ?? '');
        $amount = filter_var($data['amount'] ?? null, FILTER_VALIDATE_FLOAT);
        $method = (string)($data['method'] ?? '');
        $reference = trim((string)($data['reference'] ?? ''));
        if (!$rentalId || !in_array($type, ['rental_fee', 'deposit', 'refund', 'fine'], true) ||
            $amount === false || $amount <= 0 || $amount > 99999999.99 ||
            !in_array($method, ['Cash', 'GCash', 'Maya', 'Other'], true) || strlen($reference) > 120) {
            respond(422, ['error' => 'Choose a rental and payment type, enter a positive amount, and select a valid payment method.']);
        }
        $rental = $db->prepare('SELECT id FROM rentals WHERE id = :id');
        $rental->execute(['id' => $rentalId]);
        if (!$rental->fetchColumn()) {
            respond(404, ['error' => 'The selected rental could not be found.']);
        }
        $insert = $db->prepare(
            'INSERT INTO payment_records (rental_id, recorded_by, payment_type, amount, method, reference)
             VALUES (:rental_id, :recorded_by, :payment_type, :amount, :method, :reference)'
        );
        $insert->execute([
            'rental_id' => $rentalId,
            'recorded_by' => $admin['id'],
            'payment_type' => $type,
            'amount' => $amount,
            'method' => $method,
            'reference' => $reference === '' ? null : $reference,
        ]);
        respond(201, ['id' => (string)$db->lastInsertId()]);
    }

    if ($action === 'overdue-broadcast' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_method('POST');
        $admin = require_admin();
        sync_overdue_records($db);
        $overdue = $db->query(
            "SELECT r.id, r.user_id AS userId, r.due_date AS dueDate,
                    u.full_name AS student, i.name AS item
             FROM overdue_records o
             JOIN rentals r ON r.id = o.rental_id
             JOIN users u ON u.id = r.user_id
             JOIN inventory i ON i.id = r.inventory_id
             WHERE o.status = 'open' AND r.status = 'active'
             ORDER BY r.user_id, r.due_date"
        )->fetchAll();
        $byUser = [];
        foreach ($overdue as $rental) {
            $userId = (int)$rental['userId'];
            if (!isset($byUser[$userId])) {
                $byUser[$userId] = ['student' => $rental['student'], 'rentals' => []];
            }
            $byUser[$userId]['rentals'][] = $rental;
        }
        if (!$byUser) {
            respond(200, ['sent' => 0, 'message' => 'There are no overdue rentals to notify.']);
        }
        $insert = $db->prepare(
            'INSERT INTO notifications (user_id, rental_id, subject, message, created_by)
             VALUES (:user_id, :rental_id, :subject, :message, :created_by)'
        );
        $db->beginTransaction();
        foreach ($byUser as $userId => $recipient) {
            foreach ($recipient['rentals'] as $rental) {
                $insert->execute([
                    'user_id' => $userId,
                    'rental_id' => $rental['id'],
                    'subject' => 'Overdue rental reminder',
                    'message' => 'Your rental of ' . $rental['item'] . ' (LN-' . $rental['id'] .
                        ') was due on ' . $rental['dueDate'] . '. Please contact rental staff to arrange its return.',
                    'created_by' => $admin['id'],
                ]);
            }
        }
        $db->commit();
        respond(201, ['sent' => count($overdue), 'recipients' => count($byUser)]);
    }

    if ($action === 'due-today-broadcast' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_method('POST');
        $admin = require_admin();
        $dueToday = $db->query(
            "SELECT r.id, r.user_id AS userId, r.due_date AS dueDate,
                    u.full_name AS student, i.name AS item
             FROM rentals r
             JOIN users u ON u.id = r.user_id
             JOIN inventory i ON i.id = r.inventory_id
             WHERE r.status = 'active' AND r.due_date = CURDATE()
             ORDER BY r.user_id, r.due_date"
        )->fetchAll();
        $byUser = [];
        foreach ($dueToday as $rental) {
            $userId = (int)$rental['userId'];
            if (!isset($byUser[$userId])) {
                $byUser[$userId] = ['student' => $rental['student'], 'rentals' => []];
            }
            $byUser[$userId]['rentals'][] = $rental;
        }
        if (!$byUser) {
            respond(200, ['sent' => 0, 'recipients' => 0, 'message' => 'There are no active rentals due today to notify.']);
        }
        $insert = $db->prepare(
            'INSERT INTO notifications (user_id, rental_id, subject, message, created_by)
             VALUES (:user_id, :rental_id, :subject, :message, :created_by)'
        );
        $db->beginTransaction();
        foreach ($byUser as $userId => $recipient) {
            foreach ($recipient['rentals'] as $rental) {
                $insert->execute([
                    'user_id' => $userId,
                    'rental_id' => $rental['id'],
                    'subject' => 'Due Today Reminder',
                    'message' => 'Friendly reminder: Your rental of ' . $rental['item'] . ' (LN-' . $rental['id'] .
                        ') is due today (' . $rental['dueDate'] . '). Please return equipment to the CTU Student Hub on time.',
                    'created_by' => $admin['id'],
                ]);
            }
        }
        $db->commit();
        respond(201, ['sent' => count($dueToday), 'recipients' => count($byUser)]);
    }

    if ($action === 'deposit-refund-broadcast' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_method('POST');
        $admin = require_admin();
        $returnedRentals = $db->query(
            "SELECT r.id, r.user_id AS userId, r.deposit AS deposit,
                    u.full_name AS student, i.name AS item
             FROM rentals r
             JOIN users u ON u.id = r.user_id
             JOIN inventory i ON i.id = r.inventory_id
             WHERE r.status = 'returned'
             ORDER BY r.returned_at DESC LIMIT 50"
        )->fetchAll();
        $byUser = [];
        foreach ($returnedRentals as $rental) {
            $userId = (int)$rental['userId'];
            if (!isset($byUser[$userId])) {
                $byUser[$userId] = ['student' => $rental['student'], 'rentals' => []];
            }
            $byUser[$userId]['rentals'][] = $rental;
        }
        if (!$byUser) {
            respond(200, ['sent' => 0, 'recipients' => 0, 'message' => 'There are no returned rentals with deposit refunds to notify.']);
        }
        $insert = $db->prepare(
            'INSERT INTO notifications (user_id, rental_id, subject, message, created_by)
             VALUES (:user_id, :rental_id, :subject, :message, :created_by)'
        );
        $db->beginTransaction();
        $count = 0;
        foreach ($byUser as $userId => $recipient) {
            foreach ($recipient['rentals'] as $rental) {
                $depAmt = number_format((float)$rental['deposit'], 2);
                $insert->execute([
                    'user_id' => $userId,
                    'rental_id' => $rental['id'],
                    'subject' => 'Deposit Refund Receipt',
                    'message' => 'Your refundable security deposit of ₱' . $depAmt . ' for ' . $rental['item'] . ' (LN-' . $rental['id'] .
                        ') has been approved and processed for refund following return inspection.',
                    'created_by' => $admin['id'],
                ]);
                $count++;
            }
        }
        $db->commit();
        respond(201, ['sent' => $count, 'recipients' => count($byUser)]);
    }

    if ($action === 'custom-notification' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_method('POST');
        $admin = require_admin();
        $data = request_data();
        $recipient = trim((string)($data['recipient'] ?? ''));
        $subject = required_string($data, 'subject', 190);
        $message = required_string($data, 'message', 2000);

        if ($recipient === '' || strtolower($recipient) === 'all') {
            $users = $db->query("SELECT id FROM users")->fetchAll(PDO::FETCH_COLUMN);
        } else {
            $findUser = $db->prepare("SELECT id FROM users WHERE LOWER(student_id) = LOWER(:rec) OR LOWER(email) = LOWER(:rec) LIMIT 1");
            $findUser->execute(['rec' => $recipient]);
            $uId = $findUser->fetchColumn();
            if (!$uId) {
                respond(404, ['error' => 'No student found with Student ID or email: ' . $recipient]);
            }
            $users = [$uId];
        }

        if (!$users) {
            respond(404, ['error' => 'No student accounts found.']);
        }

        $insert = $db->prepare(
            'INSERT INTO notifications (user_id, subject, message, created_by)
             VALUES (:user_id, :subject, :message, :created_by)'
        );
        $db->beginTransaction();
        foreach ($users as $userId) {
            $insert->execute([
                'user_id' => (int)$userId,
                'subject' => $subject,
                'message' => $message,
                'created_by' => $admin['id'],
            ]);
        }
        $db->commit();
        respond(201, ['sent' => count($users), 'message' => 'Custom notification sent to ' . count($users) . ' student(s).']);
    }

    if ($action === 'notifications' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $user = require_user();
        $statement = $db->prepare(
            'SELECT id, subject, message, DATE_FORMAT(created_at, "%Y-%m-%d %H:%i") AS date,
                    read_at IS NULL AS unread
             FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 100'
        );
        $statement->execute(['user_id' => $user['id']]);
        respond(200, ['notifications' => $statement->fetchAll()]);
    }

    if ($action === 'notifications-read' && $_SERVER['REQUEST_METHOD'] === 'PATCH') {
        require_method('PATCH');
        $user = require_user();
        $statement = $db->prepare(
            'UPDATE notifications SET read_at = NOW() WHERE user_id = :user_id AND read_at IS NULL'
        );
        $statement->execute(['user_id' => $user['id']]);
        respond(200, ['updated' => $statement->rowCount()]);
    }

    if ($action === 'rentals' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_method('POST');
        $user = current_user();
        if ($user === null) {
            respond(401, ['error' => 'Please log in to continue.']);
        }
        $data = request_data();
        $targetUserId = (int)$user['id'];
        $itemId = filter_var($data['itemId'] ?? null, FILTER_VALIDATE_INT);
        $days = filter_var($data['days'] ?? null, FILTER_VALIDATE_INT);
        $paymentMethod = (string)($data['paymentMethod'] ?? '');
        $startDate = (string)($data['startDate'] ?? '');
        $settings = $db->query(
            'SELECT max_duration_days, deposit_percent FROM system_settings WHERE id = 1'
        )->fetch();
        if (!$settings) {
            throw new RuntimeException('System settings row is missing.');
        }
        $maxDuration = (int)$settings['max_duration_days'];
        if (!$itemId || !$days || $days < 1 || $days > $maxDuration ||
            !valid_iso_date($startDate) || $startDate < date('Y-m-d') ||
            !in_array($paymentMethod, ['Cash', 'GCash', 'Maya'], true)) {
            respond(422, ['error' => 'Choose an item, a valid start date, a duration from 1 to ' . $maxDuration . ' days, and a valid payment method.']);
        }
        $dueDate = (new DateTimeImmutable($startDate))->modify('+' . $days . ' days')->format('Y-m-d');
        $db->beginTransaction();
        $itemQuery = $db->prepare('SELECT id, daily_rate FROM inventory WHERE id = :id AND is_active = 1 FOR UPDATE');
        $itemQuery->execute(['id' => $itemId]);
        $item = $itemQuery->fetch();
        if (!$item) {
            $db->rollBack();
            respond(404, ['error' => 'The selected item no longer exists.']);
        }
        if (available_units_for_period($db, (int)$itemId, $startDate, $dueDate) < 1) {
            $db->rollBack();
            respond(409, ['error' => 'This item is unavailable for the selected dates. Choose another date or item.']);
        }
        $depositAmount = round(
            (float)$item['daily_rate'] * $days * ((float)$settings['deposit_percent'] / 100),
            2
        );
        $insert = $db->prepare(
            "INSERT INTO rentals (user_id, inventory_id, start_date, due_date, daily_rate, deposit, payment_method, status)
             VALUES (:user_id, :inventory_id, :start_date, :due_date, :daily_rate, :deposit, :payment_method, :status)"
        );
        $insert->bindValue(':user_id', $targetUserId, PDO::PARAM_INT);
        $insert->bindValue(':inventory_id', $itemId, PDO::PARAM_INT);
        $insert->bindValue(':start_date', $startDate);
        $insert->bindValue(':due_date', $dueDate);
        $insert->bindValue(':daily_rate', $item['daily_rate']);
        $insert->bindValue(':deposit', $depositAmount);
        $insert->bindValue(':payment_method', $paymentMethod);
        $insert->bindValue(':status', 'pending');
        $insert->execute();
        $rentalId = (int)$db->lastInsertId();

        $db->commit();
        respond(201, [
            'rentalId' => $rentalId,
            'status' => 'pending',
            'startDate' => $startDate,
            'dueDate' => $dueDate,
            'rentalFee' => round((float)$item['daily_rate'] * $days, 2),
            'deposit' => $depositAmount,
        ]);
    }

    if ($action === 'rental-request' && $_SERVER['REQUEST_METHOD'] === 'PATCH') {
        require_method('PATCH');
        $admin = require_admin();
        $data = request_data();
        $rentalId = filter_var($data['id'] ?? null, FILTER_VALIDATE_INT);
        $decision = (string)($data['decision'] ?? '');
        if (!$rentalId || !in_array($decision, ['approve', 'reject'], true)) {
            respond(422, ['error' => 'Choose a valid rental request and approval decision.']);
        }
        $db->beginTransaction();
        $requestQuery = $db->prepare(
            'SELECT id, user_id, inventory_id, start_date, due_date, status
             FROM rentals WHERE id = :id FOR UPDATE'
        );
        $requestQuery->execute(['id' => $rentalId]);
        $request = $requestQuery->fetch();
        if (!$request || $request['status'] !== 'pending') {
            $db->rollBack();
            respond(409, ['error' => 'This request is no longer pending review. Refresh the rental list.']);
        }
        if ($decision === 'approve') {
            if ($request['start_date'] < date('Y-m-d')) {
                $db->rollBack();
                respond(409, ['error' => 'The requested start date has passed. Ask the student to submit a new request with a future date.']);
            }
            $inventoryLock = $db->prepare('SELECT id FROM inventory WHERE id = :id FOR UPDATE');
            $inventoryLock->execute(['id' => $request['inventory_id']]);
            if (available_units_for_period(
                $db,
                (int)$request['inventory_id'],
                (string)$request['start_date'],
                (string)$request['due_date'],
                (int)$request['id']
            ) < 1) {
                $db->rollBack();
                respond(409, ['error' => 'No units are available for this request’s dates. Reject the request or contact the student.']);
            }
        }
        $nextStatus = $decision === 'approve' ? 'approved' : 'rejected';
        $update = $db->prepare('UPDATE rentals SET status = :status WHERE id = :id AND status = \'pending\'');
        $update->execute(['status' => $nextStatus, 'id' => $rentalId]);
        $subject = $decision === 'approve' ? 'Rental request approved' : 'Rental request rejected';
        $message = $decision === 'approve'
            ? 'Your rental request has been approved. Please coordinate payment and item pickup with the administrator.'
            : 'Your rental request was reviewed and rejected. Please contact the administrator if you need more information.';
        $notify = $db->prepare(
            'INSERT INTO notifications (user_id, rental_id, subject, message, created_by)
             VALUES (:user_id, :rental_id, :subject, :message, :created_by)'
        );
        $notify->execute([
            'user_id' => $request['user_id'],
            'rental_id' => $rentalId,
            'subject' => $subject,
            'message' => $message,
            'created_by' => $admin['id'],
        ]);
        $db->commit();
        respond(200, ['ok' => true, 'status' => $nextStatus]);
    }

    if ($action === 'rental-pickup' && $_SERVER['REQUEST_METHOD'] === 'PATCH') {
        require_method('PATCH');
        require_admin();
        $data = request_data();
        $rentalId = filter_var($data['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$rentalId) {
            respond(422, ['error' => 'A valid approved rental is required.']);
        }
        $db->beginTransaction();
        $rentalQuery = $db->prepare(
            'SELECT id, user_id, start_date, due_date, daily_rate, deposit, payment_method, status
             FROM rentals WHERE id = :id FOR UPDATE'
        );
        $rentalQuery->execute(['id' => $rentalId]);
        $rental = $rentalQuery->fetch();
        if (!$rental || $rental['status'] !== 'approved') {
            $db->rollBack();
            respond(409, ['error' => 'Only approved rentals can be marked as picked up.']);
        }
        if ($rental['start_date'] > date('Y-m-d')) {
            $db->rollBack();
            respond(409, ['error' => 'Pickup can only be recorded on or after the approved rental start date.']);
        }
        $duration = max(1, (int)(new DateTimeImmutable($rental['start_date']))->diff(
            new DateTimeImmutable($rental['due_date'])
        )->days);
        $requiredFee = round((float)$rental['daily_rate'] * $duration, 2);
        $paymentsQuery = $db->prepare(
            "SELECT payment_type, COALESCE(SUM(amount), 0) AS total
             FROM payment_records WHERE rental_id = :id AND payment_type IN ('rental_fee', 'deposit')
             GROUP BY payment_type"
        );
        $paymentsQuery->execute(['id' => $rentalId]);
        $paid = ['rental_fee' => 0.0, 'deposit' => 0.0];
        foreach ($paymentsQuery->fetchAll() as $payment) {
            $paid[$payment['payment_type']] = (float)$payment['total'];
        }
        if ($paid['rental_fee'] < $requiredFee || $paid['deposit'] < (float)$rental['deposit']) {
            $db->rollBack();
            respond(409, ['error' => 'Record and verify the full rental fee and security deposit in Payment Management before pickup.']);
        }
        $update = $db->prepare('UPDATE rentals SET status = \'active\' WHERE id = :id AND status = \'approved\'');
        $update->execute(['id' => $rentalId]);
        $db->commit();
        respond(200, ['ok' => true, 'status' => 'active']);
    }

    if ($action === 'inventory' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_method('POST');
        require_admin();
        $data = request_data();
        $name = required_string($data, 'name', 190);
        $category = required_string($data, 'category', 30);
        $description = required_string($data, 'desc', 2000);
        $categoryLabel = required_string($data, 'catLabel', 100);
        $condition = (string)($data['condition'] ?? 'Good');
        $specs = $data['specs'] ?? [];
        $dailyRate = filter_var($data['dailyRate'] ?? null, FILTER_VALIDATE_FLOAT);
        $deposit = filter_var($data['deposit'] ?? null, FILTER_VALIDATE_FLOAT);
        $total = filter_var($data['total'] ?? null, FILTER_VALIDATE_INT);
        if (!valid_category($category) || !in_array($condition, ['Excellent', 'Good', 'Fair'], true) ||
            !is_array($specs) || $dailyRate === false || $dailyRate < 0 || $deposit === false || $deposit < 0 ||
            $total === false || $total < 1) {
            respond(422, ['error' => 'Check the category, condition, rate, deposit, stock, and item specifications.']);
        }
        $statement = $db->prepare(
            'INSERT INTO inventory (name, category, category_label, description, specs, daily_rate, deposit, stock_total, item_condition)
             VALUES (:name, :category, :category_label, :description, :specs, :daily_rate, :deposit, :stock_total, :item_condition)'
        );
        $statement->execute([
            'name' => $name, 'category' => $category, 'category_label' => $categoryLabel,
            'description' => $description, 'specs' => json_encode(array_values($specs), JSON_UNESCAPED_UNICODE),
            'daily_rate' => $dailyRate, 'deposit' => $deposit, 'stock_total' => $total, 'item_condition' => $condition,
        ]);
        respond(201, ['id' => (string)$db->lastInsertId()]);
    }

    if (in_array($action, ['inventory-update', 'inventory-delete'], true)) {
        require_admin();
        $itemId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$itemId) {
            respond(422, ['error' => 'A valid item ID is required.']);
        }
        if ($action === 'inventory-delete') {
            require_method('DELETE');
            $reserved = $db->prepare("SELECT COUNT(*) FROM rentals WHERE inventory_id = :id AND status IN ('pending', 'approved', 'active')");
            $reserved->execute(['id' => $itemId]);
            if ((int)$reserved->fetchColumn() > 0) {
                respond(409, ['error' => 'Items with pending requests or unreturned rentals cannot be deleted.']);
            }
            $statement = $db->prepare('UPDATE inventory SET is_active = 0 WHERE id = :id AND is_active = 1');
            $statement->execute(['id' => $itemId]);
            if (!$statement->rowCount()) {
                respond(404, ['error' => 'Item not found.']);
            }
            respond(200, ['ok' => true]);
        }
        require_method('PUT');
        $data = request_data();
        $name = required_string($data, 'name', 190);
        $category = required_string($data, 'category', 30);
        $description = required_string($data, 'desc', 2000);
        $categoryLabel = required_string($data, 'catLabel', 100);
        $condition = (string)($data['condition'] ?? 'Good');
        $specs = $data['specs'] ?? [];
        $dailyRate = filter_var($data['dailyRate'] ?? null, FILTER_VALIDATE_FLOAT);
        $deposit = filter_var($data['deposit'] ?? null, FILTER_VALIDATE_FLOAT);
        $total = filter_var($data['total'] ?? null, FILTER_VALIDATE_INT);
        if (!valid_category($category) || !in_array($condition, ['Excellent', 'Good', 'Fair'], true) ||
            !is_array($specs) || $dailyRate === false || $dailyRate < 0 || $deposit === false || $deposit < 0 ||
            $total === false || $total < 1) {
            respond(422, ['error' => 'Check the category, condition, rate, deposit, stock, and item specifications.']);
        }
        $active = $db->prepare("SELECT COUNT(*) FROM rentals WHERE inventory_id = :id AND status = 'active'");
        $active->execute(['id' => $itemId]);
        if ($total < (int)$active->fetchColumn()) {
            respond(409, ['error' => 'Stock cannot be lower than the number of active rentals.']);
        }
        $statement = $db->prepare(
            'UPDATE inventory SET name=:name, category=:category, category_label=:category_label,
             description=:description, specs=:specs, daily_rate=:daily_rate, deposit=:deposit,
             stock_total=:stock_total, item_condition=:item_condition WHERE id=:id AND is_active=1'
        );
        $statement->execute([
            'id' => $itemId, 'name' => $name, 'category' => $category, 'category_label' => $categoryLabel,
            'description' => $description, 'specs' => json_encode(array_values($specs), JSON_UNESCAPED_UNICODE),
            'daily_rate' => $dailyRate, 'deposit' => $deposit, 'stock_total' => $total, 'item_condition' => $condition,
        ]);
        respond(200, ['ok' => true]);
    }

    if ($action === 'rental-return') {
        require_method('PATCH');
        $admin = require_admin();
        $data = request_data();
        $rentalId = filter_var($data['id'] ?? null, FILTER_VALIDATE_INT);
        $condition = (string)($data['condition'] ?? 'Good');
        $notes = trim((string)($data['notes'] ?? ''));
        if (!$rentalId || !in_array($condition, ['Excellent', 'Good', 'Fair', 'Damaged'], true) ||
            strlen($notes) > 2000) {
            respond(422, ['error' => 'Choose a valid rental, return condition, and note of no more than 2,000 characters.']);
        }
        $db->beginTransaction();
        $rentalQuery = $db->prepare('SELECT id, due_date, status FROM rentals WHERE id = :id FOR UPDATE');
        $rentalQuery->execute(['id' => $rentalId]);
        $rental = $rentalQuery->fetch();
        if (!$rental || $rental['status'] !== 'active') {
            $db->rollBack();
            respond(404, ['error' => 'Active rental not found.']);
        }
        $overdueInsert = $db->prepare(
            "INSERT INTO overdue_records (rental_id, days_overdue, status)
             SELECT id, DATEDIFF(CURDATE(), due_date), 'open'
             FROM rentals WHERE id = :rental_id AND due_date < CURDATE()
             ON DUPLICATE KEY UPDATE days_overdue = VALUES(days_overdue), status = 'open', resolved_at = NULL"
        );
        $overdueInsert->execute(['rental_id' => $rentalId]);
        $returnInsert = $db->prepare(
            'INSERT INTO rental_returns (rental_id, processed_by, condition_on_return, notes)
             VALUES (:rental_id, :processed_by, :condition, :notes)'
        );
        $returnInsert->execute([
            'rental_id' => $rentalId,
            'processed_by' => $admin['id'],
            'condition' => $condition,
            'notes' => $notes === '' ? null : $notes,
        ]);
        $statement = $db->prepare(
            "UPDATE rentals SET status = 'returned', returned_at = NOW()
             WHERE id = :id AND status = 'active'"
        );
        $statement->execute(['id' => $rentalId]);
        $resolveOverdue = $db->prepare(
            "UPDATE overdue_records SET status = 'resolved', resolved_at = NOW()
             WHERE rental_id = :rental_id AND status = 'open'"
        );
        $resolveOverdue->execute(['rental_id' => $rentalId]);
        $db->commit();
        respond(200, ['ok' => true]);
    }

    respond(404, ['error' => 'Unknown API action.']);
} catch (Throwable $exception) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('API request failed: ' . $exception->getMessage());
    respond(500, ['error' => 'The request could not be completed. Check the PHP error log for details.']);
}
